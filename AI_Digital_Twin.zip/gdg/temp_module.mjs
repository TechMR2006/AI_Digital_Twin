
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const state = {
  time:12,weather:'sunny',cameraMode:'orbit',autoTime:true,trafficEnabled:true,
  pedestriansEnabled:true,soundEnabled:false,photoMode:false,
  introComplete:false,fps:60,frameCount:0,lastFpsTime:performance.now(),
  floodLevel:0,autoFlood:false,showEvacuation:false,
  earthquakeIntensity:0,fireSimulation:false,aiActive:true,
};

const container = document.getElementById('canvas-container');
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x87CEEB,0.0018);

const camera = new THREE.PerspectiveCamera(58,window.innerWidth/window.innerHeight,0.1,2000);
const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: 'high-performance',
  preserveDrawingBuffer: true,
  precision: 'mediump'
});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5)); // Cap pixel ratio to 1.5 for steady 60 FPS
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = true;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
renderer.outputColorSpace = THREE.SRGBColorSpace;
container.appendChild(renderer.domElement);

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene,camera));
const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth,window.innerHeight),0.35,0.4,0.82);
composer.addPass(bloomPass);

const controls = new OrbitControls(camera,renderer.domElement);
controls.enableDamping = true;controls.dampingFactor = 0.05;
controls.maxPolarAngle = Math.PI/2.08;controls.minDistance = 5;controls.maxDistance = 350;
controls.target.set(0,5,0);

const C = {road:0x252525,sidewalk:0x888888,grass:0x4a7c59,parkGrass:0x3a6e49,
  ocean:0x1a5f7a,sand:0xE8DCC8,buildingGlass:0x87CEEB,buildingConcrete:0xCCCCCC,
  buildingLight:0xEEEEEE,buildingDark:0x5a5a5a,
  nightSky:0x050510,daySky:0x87CEEB,sunsetSky:0xFF7830};

// LIGHTS
const ambientLight = new THREE.AmbientLight(0xffffff, 0.4); scene.add(ambientLight);
const sunLight = new THREE.DirectionalLight(0xfffbe8, 1.6);
sunLight.position.set(50,120,50);
sunLight.castShadow = true;
sunLight.shadow.mapSize.width = 2048; // Optimized for 60 FPS performance without visual quality degradation
sunLight.shadow.mapSize.height = 2048;
sunLight.shadow.camera.near = 0.5;
sunLight.shadow.camera.far = 400;
sunLight.shadow.camera.left = -160;
sunLight.shadow.camera.right = 160;
sunLight.shadow.camera.top = 160;
sunLight.shadow.camera.bottom = -160;
sunLight.shadow.bias = -0.0003;
scene.add(sunLight);
const moonLight = new THREE.DirectionalLight(0x6688aa, 0.35);
moonLight.position.set(-50,80,-50);moonLight.visible = false;scene.add(moonLight);
const hemiLight = new THREE.HemisphereLight(0x87CEEB, 0x4a7c59, 0.5);scene.add(hemiLight);

// SKY & STARS
const skyMat=new THREE.MeshBasicMaterial({color:C.daySky,side:THREE.BackSide});
scene.add(new THREE.Mesh(new THREE.SphereGeometry(900,32,32),skyMat));
const starsGeo=new THREE.BufferGeometry();
const sP=new Float32Array(3500*3);
for(let i=0;i<3500*3;i+=3){const t=Math.random()*Math.PI*2,p=Math.acos(Math.random()*2-1),r=800;sP[i]=r*Math.sin(p)*Math.cos(t);sP[i+1]=r*Math.sin(p)*Math.sin(t);sP[i+2]=r*Math.cos(p);}
starsGeo.setAttribute('position',new THREE.BufferAttribute(sP,3));
const starsMat=new THREE.PointsMaterial({color:0xffffff,size:1.4,transparent:true,opacity:0});
scene.add(new THREE.Points(starsGeo,starsMat));

// GROUND
const groundMat=new THREE.MeshStandardMaterial({color:C.grass,roughness:0.9});
const ground=new THREE.Mesh(new THREE.PlaneGeometry(500,500,50,50),groundMat);
ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);

// OCEAN
const oceanGeo=new THREE.PlaneGeometry(500,250,80,40);
const oceanMat=new THREE.MeshStandardMaterial({color:C.ocean,roughness:0.1,metalness:0.85,transparent:true,opacity:0.87});
const ocean=new THREE.Mesh(oceanGeo,oceanMat);
ocean.rotation.x=-Math.PI/2;ocean.position.set(0,-1.5,-130);scene.add(ocean);
const oceanOrigPos=oceanGeo.attributes.position.clone();

const beach=new THREE.Mesh(new THREE.PlaneGeometry(500,30),new THREE.MeshStandardMaterial({color:C.sand,roughness:1.0}));
beach.rotation.x=-Math.PI/2;beach.position.set(0,0.05,-50);beach.receiveShadow=true;scene.add(beach);

// FLOOD
const floodGeo=new THREE.PlaneGeometry(500,500,50,50);
const floodMat=new THREE.MeshStandardMaterial({color:0x2266aa,roughness:0.05,metalness:0.9,transparent:true,opacity:0.72});
const floodWater=new THREE.Mesh(floodGeo,floodMat);
floodWater.rotation.x=-Math.PI/2;floodWater.position.set(0,-10,0);floodWater.visible=false;scene.add(floodWater);

// ============================================================
// GRID ROAD SYSTEM
// ============================================================
function createRoad(x,z,width,length,isNS){
  const geo=new THREE.PlaneGeometry(isNS?width:length,isNS?length:width);
  const mat=new THREE.MeshStandardMaterial({color:C.road,roughness:0.88});
  const road=new THREE.Mesh(geo,mat);
  road.rotation.x=-Math.PI/2;road.position.set(x,0.02,z);road.receiveShadow=true;scene.add(road);
  if(width>8){
    const lineGeo=new THREE.PlaneGeometry(isNS?0.22:length,isNS?length:0.22);
    const line=new THREE.Mesh(lineGeo,new THREE.MeshBasicMaterial({color:0xffffff}));
    line.rotation.x=-Math.PI/2;line.position.set(x,0.035,z);scene.add(line);
  }
}
function createSidewalk(x,z,w,l){
  const sw=new THREE.Mesh(new THREE.PlaneGeometry(w,l),new THREE.MeshStandardMaterial({color:0x9a9a9a,roughness:0.85}));
  sw.rotation.x=-Math.PI/2;sw.position.set(x,0.04,z);sw.receiveShadow=true;scene.add(sw);
}

// Main roads
createRoad(0,0,14,280,true);   // Main N-S road at x=0
createRoad(0,0,280,14,false);  // Main E-W road at z=0
createRoad(-60,20,10,140,true); // Secondary N-S
createRoad(60,20,10,140,true);
createRoad(0,-40,160,10,false); // Secondary E-W
createRoad(0,40,160,10,false);
createRoad(0,80,160,10,false);

// Sidewalks
createSidewalk(0,9,280,3);
createSidewalk(0,-9,280,3);
createSidewalk(9,0,3,280);
createSidewalk(-9,0,3,280);

// ============================================================
// BUILDINGS — GRID BLOCKS ONLY
// ============================================================
const buildings=[], buildingLights=[], buildingOrigPos=[];

function createBuilding(x,z,w,d,h,type){
  const g=new THREE.Group();
  g.position.set(x,0,z);
  let mat;
  if(type==='skyscraper') mat=new THREE.MeshStandardMaterial({color:C.buildingGlass,roughness:0.08,metalness:0.92,transparent:true,opacity:0.72});
  else if(type==='modern') mat=new THREE.MeshStandardMaterial({color:C.buildingLight,roughness:0.28,metalness:0.4});
  else if(type==='residential') mat=new THREE.MeshStandardMaterial({color:C.buildingConcrete,roughness:0.7,metalness:0.1});
  else mat=new THREE.MeshStandardMaterial({color:C.buildingDark,roughness:0.5,metalness:0.28});

  const body=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
  body.position.y=h/2;body.castShadow=true;body.receiveShadow=true;g.add(body);

  const winRows=Math.floor(h/3.5),winCols=Math.floor(w/3);
  for(let r=0;r<winRows;r++){
    for(let c=0;c<winCols;c++){
      const wMat=new THREE.MeshStandardMaterial({color:0x87CEEB,roughness:0.05,metalness:0.95,emissive:0x223344,emissiveIntensity:0.08});
      const win=new THREE.Mesh(new THREE.PlaneGeometry(1.4,1.8),wMat);
      win.position.set(-w/2+1.8+c*3,2.5+r*3.5,d/2+0.01);g.add(win);buildingLights.push(wMat);
      const wb=win.clone();wb.position.z=-d/2-0.01;wb.rotation.y=Math.PI;g.add(wb);buildingLights.push(wb.material);
    }
  }
  if(h>20){
    const ant=new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,5,8),new THREE.MeshStandardMaterial({color:0x888888}));
    ant.position.y=h+2.5;g.add(ant);
    const bMat=new THREE.MeshStandardMaterial({color:0xff0000,emissive:0xff0000,emissiveIntensity:2});
    const beacon=new THREE.Mesh(new THREE.SphereGeometry(0.22,8,8),bMat);
    beacon.position.y=h+5;g.add(beacon);
  }
  if(type==='residential'&&h>10){
    for(let i=1;i<h/5;i++){
      const bal=new THREE.Mesh(new THREE.BoxGeometry(w+0.8,0.25,1.8),new THREE.MeshStandardMaterial({color:0xaaaaaa}));
      bal.position.set(0,i*5,d/2+0.8);g.add(bal);
    }
  }
  scene.add(g);buildings.push(g);buildingOrigPos.push(new THREE.Vector3(x,0,z));
  return g;
}

function populateBlock(xMin,xMax,zMin,zMax,type,heightMin,heightMax){
  const bW=xMax-xMin,bD=zMax-zMin;
  const cols=Math.max(1,Math.floor(bW/20)),rows=Math.max(1,Math.floor(bD/20));
  const cW=bW/cols,cD=bD/rows;
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const cx=xMin+(c+0.5)*cW+(Math.random()-0.5)*3;
      const cz=zMin+(r+0.5)*cD+(Math.random()-0.5)*3;
      // Guard against roads
      if(Math.abs(cx)<10||Math.abs(cz)<10) continue;
      if(Math.abs(cx-60)<8||Math.abs(cx+60)<8) continue;
      if(Math.abs(cz-40)<7||Math.abs(cz+40)<7) continue;
      if(Math.abs(cz-80)<7||Math.abs(cz+80)<7) continue;
      const bw=6+Math.random()*8,bd=6+Math.random()*8;
      const bh=heightMin+Math.random()*(heightMax-heightMin);
      createBuilding(cx,cz,bw,bd,bh,type);
    }
  }
}

// Downtown core — skyscrapers
populateBlock(-55,-12,8,35,'skyscraper',35,85);
populateBlock(12,55,8,35,'skyscraper',35,85);
// Midtown — modern
populateBlock(-55,-12,-38,-12,'modern',15,32);
populateBlock(12,55,-38,-12,'modern',15,32);
// Uptown — residential
populateBlock(-55,-12,45,75,'residential',8,22);
populateBlock(12,55,45,75,'modern',10,28);
// Outer west
populateBlock(-115,-65,-35,75,'residential',6,18);
// Outer east (excluding park zone x:65-125, z:18-84)
populateBlock(65,125,-35,14,'modern',8,22);
// Landmark buildings — placed in blocks without intersecting roads or sidewalks
createBuilding(-28,22,22,16,65,'skyscraper');
createBuilding(28,22,18,14,58,'skyscraper');

// ============================================================
// TREES
// ============================================================
const trees=[];
function createTree(x,z,s,type){
  const g=new THREE.Group();
  g.position.set(x,0,z);g.scale.setScalar(s||1);
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.45,3,8),new THREE.MeshStandardMaterial({color:0x5c4033}));
  trunk.position.y=1.5;trunk.castShadow=true;g.add(trunk);
  if(type==='palm'){
    const f=new THREE.Mesh(new THREE.SphereGeometry(2,8,6),new THREE.MeshStandardMaterial({color:0x4a7c3f}));
    f.position.y=4.5;f.scale.y=0.5;f.castShadow=true;g.add(f);
  } else {
    const fMat=new THREE.MeshStandardMaterial({color:0x8FA28A});
    const f=new THREE.Mesh(new THREE.SphereGeometry(2.4,8,6),fMat);
    f.position.y=4.2;f.castShadow=true;g.add(f);
    const f2=new THREE.Mesh(new THREE.SphereGeometry(1.6,8,6),fMat);
    f2.position.y=5.8;f2.castShadow=true;g.add(f2);
  }
  scene.add(g);trees.push({mesh:g,type});
  return g;
}
// Sidewalk trees along N-S main road (avoiding E-W road intersections)
for(let z=-90;z<=90;z+=16){if(Math.abs(z)<12||Math.abs(z-40)<8||Math.abs(z+40)<8||Math.abs(z-80)<8) continue;createTree(12,z,0.85+Math.random()*0.3);createTree(-12,z,0.85+Math.random()*0.3);}
// Sidewalk trees along E-W main road (avoiding N-S road intersections)
for(let x=-90;x<=90;x+=16){if(Math.abs(x)<12||Math.abs(x-60)<8||Math.abs(x+60)<8) continue;createTree(x,12,0.8+Math.random()*0.3);createTree(x,-12,0.8+Math.random()*0.3);}
// Palm trees beach (placed cleanly on sand strip at z=-50, clear of z=-40 road)
for(let x=-100;x<=100;x+=14) createTree(x,-52,1.1+Math.random()*0.3,'palm');
// Park trees
for(let i=0;i<30;i++) createTree(70+Math.random()*50,20+Math.random()*60,0.8+Math.random()*0.5);

// ============================================================
// PARK ZONE (x: 65-125, z: 15-85) — perfectly bounded
// ============================================================
const parkMesh=new THREE.Mesh(new THREE.PlaneGeometry(60,70),new THREE.MeshStandardMaterial({color:C.parkGrass,roughness:0.9}));
parkMesh.rotation.x=-Math.PI/2;parkMesh.position.set(95,0.03,50);parkMesh.receiveShadow=true;scene.add(parkMesh);

// Park paths
const pathMat=new THREE.MeshStandardMaterial({color:0xb8a888});
const pp1=new THREE.Mesh(new THREE.PlaneGeometry(2,66),pathMat);
pp1.rotation.x=-Math.PI/2;pp1.position.set(95,0.05,50);scene.add(pp1);
const pp2=new THREE.Mesh(new THREE.PlaneGeometry(56,2),pathMat);
pp2.rotation.x=-Math.PI/2;pp2.position.set(95,0.05,50);scene.add(pp2);

// FOUNTAIN at park center (95, 0, 50)
const fountainGroup=new THREE.Group();
fountainGroup.position.set(95,0,50);
const basin=new THREE.Mesh(new THREE.CylinderGeometry(5,5,0.5,32),new THREE.MeshStandardMaterial({color:0x999999,roughness:0.4}));
basin.position.y=0.25;basin.receiveShadow=true;fountainGroup.add(basin);
const fCenter=new THREE.Mesh(new THREE.CylinderGeometry(0.5,1.2,2.5,16),new THREE.MeshStandardMaterial({color:0xbbbbbb}));
fCenter.position.y=1.25;fountainGroup.add(fCenter);
const rim=new THREE.Mesh(new THREE.TorusGeometry(5,0.25,8,32),new THREE.MeshStandardMaterial({color:0x888888}));
rim.rotation.x=Math.PI/2;rim.position.y=0.5;fountainGroup.add(rim);
scene.add(fountainGroup);

// Fountain particles
const fountainParticles=[];
for(let i=0;i<60;i++){
  const drop=new THREE.Mesh(new THREE.SphereGeometry(0.04,4,4),new THREE.MeshBasicMaterial({color:0x87CEEB,transparent:true,opacity:0.7}));
  drop.position.copy(fountainGroup.position);drop.position.y+=2.5;scene.add(drop);
  fountainParticles.push({mesh:drop,base:fountainGroup.position.clone(),vel:new THREE.Vector3((Math.random()-0.5)*0.18,0.12+Math.random()*0.16,(Math.random()-0.5)*0.18),life:Math.random()*80});
}

// FERRIS WHEEL in park at (82, 0, 32)
const ferrisGroup=new THREE.Group();
ferrisGroup.position.set(82,0,32);
const fSupMat=new THREE.MeshStandardMaterial({color:0x444444,metalness:0.6,roughness:0.4});

// Support A-frames (both sides)
[-1,1].forEach(sideZ=>{
  const s1=new THREE.Mesh(new THREE.CylinderGeometry(0.25,0.45,16,8),fSupMat);
  s1.position.set(-4,7.5,sideZ*1.2);s1.rotation.z=0.28;ferrisGroup.add(s1);
  const s2=new THREE.Mesh(new THREE.CylinderGeometry(0.25,0.45,16,8),fSupMat);
  s2.position.set(4,7.5,sideZ*1.2);s2.rotation.z=-0.28;ferrisGroup.add(s2);
});
const fBase=new THREE.Mesh(new THREE.BoxGeometry(11,0.6,3.5),fSupMat);
fBase.position.y=0.3;ferrisGroup.add(fBase);

// Center Axle Hub
const axleMat=new THREE.MeshStandardMaterial({color:0xC8A96B,metalness:0.8,roughness:0.2});
const fAxle=new THREE.Mesh(new THREE.CylinderGeometry(0.8,0.8,3,16),axleMat);
fAxle.rotation.x=Math.PI/2;
fAxle.position.y=15;
ferrisGroup.add(fAxle);

// Rotating Wheel Subgroup (Hub, rims, and spokes)
const wheelMeshGroup=new THREE.Group();
wheelMeshGroup.position.y=15;

const fWheelOuter=new THREE.Mesh(new THREE.TorusGeometry(10,0.22,8,48),new THREE.MeshStandardMaterial({color:0xcccccc,metalness:0.7,roughness:0.3}));
wheelMeshGroup.add(fWheelOuter);
const fWheelInner=new THREE.Mesh(new THREE.TorusGeometry(8.2,0.16,8,48),new THREE.MeshStandardMaterial({color:0x888888,metalness:0.6}));
wheelMeshGroup.add(fWheelInner);

// 12 Radial Spokes with cross struts
const spokeMat=new THREE.MeshStandardMaterial({color:0xaaaaaa,metalness:0.5});
for(let i=0;i<12;i++){
  const spAng=(i/12)*Math.PI*2;
  const spoke=new THREE.Mesh(new THREE.CylinderGeometry(0.08,0.08,19.6,6),spokeMat);
  spoke.rotation.z=spAng;
  wheelMeshGroup.add(spoke);
}
ferrisGroup.add(wheelMeshGroup);

// 12 Cabins (kept upright in world/parent coordinate space)
const cabColors=[0xcc3333,0x3366cc,0x33cc66,0xcccc33,0x9933cc,0x33cccc];
const ferrisCabins=[];
for(let i=0;i<12;i++){
  const cabG=new THREE.Group();
  const cabBody=new THREE.Mesh(new THREE.BoxGeometry(1.6,1.8,1.4),new THREE.MeshStandardMaterial({color:cabColors[i%6],metalness:0.3,roughness:0.4}));
  cabBody.position.y=-0.5;
  cabG.add(cabBody);
  // Cabin glass
  const cabGlass=new THREE.Mesh(new THREE.PlaneGeometry(1.2,0.9),new THREE.MeshStandardMaterial({color:0x87CEEB,transparent:true,opacity:0.8}));
  cabGlass.position.set(0,-0.4,0.71);cabG.add(cabGlass);
  const cabGlassBack=cabGlass.clone();cabGlassBack.position.z=-0.71;cabGlassBack.rotation.y=Math.PI;cabG.add(cabGlassBack);
  // Hanger pin
  const pin=new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.06,0.8,6),fSupMat);
  pin.position.y=0.2;pin.rotation.x=Math.PI/2;cabG.add(pin);

  ferrisGroup.add(cabG);
  ferrisCabins.push({group:cabG,index:i});
}
scene.add(ferrisGroup);

// Park benches — ring around fountain
const benchMat=new THREE.MeshStandardMaterial({color:0x8B4513});
const legMat=new THREE.MeshStandardMaterial({color:0x333333});
for(let i=0;i<8;i++){
  const ang=(i/8)*Math.PI*2;
  const bg=new THREE.Group();
  bg.position.set(95+Math.cos(ang)*13,0,50+Math.sin(ang)*13);
  bg.rotation.y=ang;
  const seat=new THREE.Mesh(new THREE.BoxGeometry(2.2,0.12,0.65),benchMat);
  seat.position.y=0.5;seat.castShadow=true;bg.add(seat);
  const back=new THREE.Mesh(new THREE.BoxGeometry(2.2,0.5,0.1),benchMat);
  back.position.set(0,0.75,-0.28);bg.add(back);
  [-0.8,0.8].forEach(lx=>{
    const leg=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.5,0.6),legMat);
    leg.position.set(lx,0.25,0);bg.add(leg);
  });
  scene.add(bg);
}

// Playground slide at (110, 0, 35)
const slideGroup=new THREE.Group();
slideGroup.position.set(110,0,35);
const platMat=new THREE.MeshStandardMaterial({color:0xFF6B6B});
const plat=new THREE.Mesh(new THREE.BoxGeometry(3,0.2,3),platMat);
plat.position.y=3;slideGroup.add(plat);
const rampMat=new THREE.MeshStandardMaterial({color:0x4ECDC4});
const ramp=new THREE.Mesh(new THREE.BoxGeometry(1.5,0.15,4),rampMat);
ramp.position.set(0,1.5,2.5);ramp.rotation.x=Math.PI/6;slideGroup.add(ramp);
const pillarMat=new THREE.MeshStandardMaterial({color:0xFFBE0B});
[[-1.2,1.75,-1.2],[1.2,1.75,-1.2],[-1.2,1.75,1.2],[1.2,1.75,1.2]].forEach(([px,py,pz])=>{
  const p=new THREE.Mesh(new THREE.CylinderGeometry(0.15,0.15,3.5,8),pillarMat);
  p.position.set(px,py,pz);p.castShadow=true;slideGroup.add(p);
});
scene.add(slideGroup);

// Swing set at (108, 0, 65)
const swingGroup=new THREE.Group();
swingGroup.position.set(108,0,65);
const swingFrameMat=new THREE.MeshStandardMaterial({color:0x666666});
const lPole=new THREE.Mesh(new THREE.BoxGeometry(0.15,4,0.15),swingFrameMat);
lPole.position.set(-3,2,0);swingGroup.add(lPole);
const rPole=new THREE.Mesh(new THREE.BoxGeometry(0.15,4,0.15),swingFrameMat);
rPole.position.set(3,2,0);swingGroup.add(rPole);
const topBar=new THREE.Mesh(new THREE.BoxGeometry(6.3,0.15,0.15),swingFrameMat);
topBar.position.y=4;swingGroup.add(topBar);
const seatMat=new THREE.MeshStandardMaterial({color:0x3A86FF});
const chainMat=new THREE.MeshStandardMaterial({color:0x888888});
[-2,0,2].forEach(sx=>{
  const seat=new THREE.Mesh(new THREE.BoxGeometry(0.8,0.08,0.4),seatMat);
  seat.position.set(sx,2,0);seat.castShadow=true;swingGroup.add(seat);
  const chain=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.04,2,4),chainMat);
  chain.position.set(sx,3,0);swingGroup.add(chain);
});
scene.add(swingGroup);

// ============================================================
// VEHICLE ROAD NETWORK GRAPH & LANE WAYPOINT ROUTING SYSTEM
// Precise road centerlines, offset lanes, smooth turns & ground alignment
// ============================================================

// Road Network Nodes (Intersections & Terminal Endpoints strictly inside road mesh bounds)
const roadNodes = {
  // Main E-W axis (z=0, road spans x: [-135, 135])
  EW0_W:  { id:'EW0_W',  x:-135, z:0 },
  INT_W0: { id:'INT_W0', x:-60,  z:0 },
  INT_C0: { id:'INT_C0', x:0,    z:0 },
  INT_E0: { id:'INT_E0', x:60,   z:0 },
  EW0_E:  { id:'EW0_E',  x:135,  z:0 },

  // E-W secondary road (z=-40, road spans x: [-75, 75])
  EW_M40_W:  { id:'EW_M40_W',  x:-75, z:-40 },
  INT_W_M40: { id:'INT_W_M40', x:-60, z:-40 },
  INT_C_M40: { id:'INT_C_M40', x:0,   z:-40 },
  INT_E_M40: { id:'INT_E_M40', x:60,  z:-40 },
  EW_M40_E:  { id:'EW_M40_E',  x:75,  z:-40 },

  // E-W secondary road (z=40, road spans x: [-75, 75])
  EW_40_W:  { id:'EW_40_W',  x:-75, z:40 },
  INT_W_40: { id:'INT_W_40', x:-60, z:40 },
  INT_C_40: { id:'INT_C_40', x:0,   z:40 },
  INT_E_40: { id:'INT_E_40', x:60,  z:40 },
  EW_40_E:  { id:'EW_40_E',  x:75,  z:40 },

  // E-W secondary road (z=80, road spans x: [-75, 75])
  EW_80_W:  { id:'EW_80_W',  x:-75, z:80 },
  INT_W_80: { id:'INT_W_80', x:-60, z:80 },
  INT_C_80: { id:'INT_C_80', x:0,   z:80 },
  INT_E_80: { id:'INT_E_80', x:60,  z:80 },
  EW_80_E:  { id:'EW_80_E',  x:75,  z:80 },

  // N-S main axis (x=0, road spans z: [-135, 135])
  NS0_N: { id:'NS0_N', x:0, z:135 },
  NS0_S: { id:'NS0_S', x:0, z:-135 },

  // N-S secondary road (x=-60, road spans z: [-45, 85])
  NSW_S: { id:'NSW_S', x:-60, z:-45 },
  NSW_N: { id:'NSW_N', x:-60, z:85 },

  // N-S secondary road (x=60, road spans z: [-45, 85])
  NSE_S: { id:'NSE_S', x:60, z:-45 },
  NSE_N: { id:'NSE_N', x:60, z:85 },
};

// Directed Road Segments with offset lanes (Forward lane shifted to right of travel direction)
// Major roads (width 14): lane offset = 3.0 units.
// Secondary roads (width 10): lane offset = 2.2 units.
const roadSegments = [
  // --- E-W Main Road (z=0, road width = 14, lane offset = 3.0) ---
  { id:'EW0_1', from:'EW0_W',  to:'INT_W0', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_1_R', from:'INT_W0', to:'EW0_W', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_2', from:'INT_W0', to:'INT_C0', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_2_R', from:'INT_C0', to:'INT_W0', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_3', from:'INT_C0', to:'INT_E0', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_3_R', from:'INT_E0', to:'INT_C0', type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_4', from:'INT_E0', to:'EW0_E',  type:'EW', z:0,  width:14, laneOffset: 3.0 },
  { id:'EW0_4_R', from:'EW0_E',  to:'INT_E0', type:'EW', z:0,  width:14, laneOffset: 3.0 },

  // --- E-W Secondary Road (z=-40, road width = 10, lane offset = 2.2) ---
  { id:'EWM40_1', from:'EW_M40_W', to:'INT_W_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_1_R', from:'INT_W_M40', to:'EW_M40_W', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_2', from:'INT_W_M40', to:'INT_C_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_2_R', from:'INT_C_M40', to:'INT_W_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_3', from:'INT_C_M40', to:'INT_E_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_3_R', from:'INT_E_M40', to:'INT_C_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_4', from:'INT_E_M40', to:'EW_M40_E',  type:'EW', z:-40, width:10, laneOffset: 2.2 },
  { id:'EWM40_4_R', from:'EW_M40_E',  to:'INT_E_M40', type:'EW', z:-40, width:10, laneOffset: 2.2 },

  // --- E-W Secondary Road (z=40, road width = 10, lane offset = 2.2) ---
  { id:'EW40_1', from:'EW_40_W', to:'INT_W_40', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_1_R', from:'INT_W_40', to:'EW_40_W', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_2', from:'INT_W_40', to:'INT_C_40', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_2_R', from:'INT_C_40', to:'INT_W_40', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_3', from:'INT_C_40', to:'INT_E_40', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_3_R', from:'INT_E_40', to:'INT_C_40', type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_4', from:'INT_E_40', to:'EW_40_E',  type:'EW', z:40, width:10, laneOffset: 2.2 },
  { id:'EW40_4_R', from:'EW_40_E',  to:'INT_E_40', type:'EW', z:40, width:10, laneOffset: 2.2 },

  // --- E-W Secondary Road (z=80, road width = 10, lane offset = 2.2) ---
  { id:'EW80_1', from:'EW_80_W', to:'INT_W_80', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_1_R', from:'INT_W_80', to:'EW_80_W', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_2', from:'INT_W_80', to:'INT_C_80', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_2_R', from:'INT_C_80', to:'INT_W_80', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_3', from:'INT_C_80', to:'INT_E_80', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_3_R', from:'INT_E_80', to:'INT_C_80', type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_4', from:'INT_E_80', to:'EW_80_E',  type:'EW', z:80, width:10, laneOffset: 2.2 },
  { id:'EW80_4_R', from:'EW_80_E',  to:'INT_E_80', type:'EW', z:80, width:10, laneOffset: 2.2 },

  // --- N-S Main Road (x=0, road width = 14, lane offset = 3.0) ---
  { id:'NS0_1', from:'NS0_S', to:'INT_C_M40', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_1_R', from:'INT_C_M40', to:'NS0_S', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_2', from:'INT_C_M40', to:'INT_C0', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_2_R', from:'INT_C0', to:'INT_C_M40', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_3', from:'INT_C0', to:'INT_C_40', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_3_R', from:'INT_C_40', to:'INT_C0', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_4', from:'INT_C_40', to:'INT_C_80', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_4_R', from:'INT_C_80', to:'INT_C_40', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_5', from:'INT_C_80', to:'NS0_N', type:'NS', x:0, width:14, laneOffset: 3.0 },
  { id:'NS0_5_R', from:'NS0_N', to:'INT_C_80', type:'NS', x:0, width:14, laneOffset: 3.0 },

  // --- N-S West Secondary Road (x=-60, road width = 10, lane offset = 2.2) ---
  { id:'NSW_1', from:'NSW_S', to:'INT_W_M40', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_1_R', from:'INT_W_M40', to:'NSW_S', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_2', from:'INT_W_M40', to:'INT_W0', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_2_R', from:'INT_W0', to:'INT_W_M40', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_3', from:'INT_W0', to:'INT_W_40', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_3_R', from:'INT_W_40', to:'INT_W0', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_4', from:'INT_W_40', to:'INT_W_80', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_4_R', from:'INT_W_80', to:'INT_W_40', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_5', from:'INT_W_80', to:'NSW_N', type:'NS', x:-60, width:10, laneOffset: 2.2 },
  { id:'NSW_5_R', from:'NSW_N', to:'INT_W_80', type:'NS', x:-60, width:10, laneOffset: 2.2 },

  // --- N-S East Secondary Road (x=60, road width = 10, lane offset = 2.2) ---
  { id:'NSE_1', from:'NSE_S', to:'INT_E_M40', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_1_R', from:'INT_E_M40', to:'NSE_S', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_2', from:'INT_E_M40', to:'INT_E0', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_2_R', from:'INT_E0', to:'INT_E_M40', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_3', from:'INT_E0', to:'INT_E_40', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_3_R', from:'INT_E_40', to:'INT_E0', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_4', from:'INT_E_40', to:'INT_E_80', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_4_R', from:'INT_E_80', to:'INT_E_40', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_5', from:'INT_E_80', to:'NSE_N', type:'NS', x:60, width:10, laneOffset: 2.2 },
  { id:'NSE_5_R', from:'NSE_N', to:'INT_E_80', type:'NS', x:60, width:10, laneOffset: 2.2 },
];

// Precompute connected road lookup per node
const nodeOutgoingSegments = {};
roadSegments.forEach(seg => {
  if (!nodeOutgoingSegments[seg.from]) nodeOutgoingSegments[seg.from] = [];
  nodeOutgoingSegments[seg.from].push(seg);
});

// Calculate angle from direction vector (Three.js standard: front of car along +Z)
function angleFromDirection(dir) {
  return Math.atan2(dir.x, dir.z);
}

// Build 3D Lane Path Waypoints for a directed segment
function getSegmentLaneWaypoints(seg) {
  const pFrom = roadNodes[seg.from];
  const pTo = roadNodes[seg.to];
  const dx = pTo.x - pFrom.x;
  const dz = pTo.z - pFrom.z;
  const len = Math.sqrt(dx * dx + dz * dz);
  if (len === 0) return [new THREE.Vector3(pFrom.x, 0, pFrom.z), new THREE.Vector3(pTo.x, 0, pTo.z)];

  // Perpendicular unit vector (points to right of travel direction)
  const perpX = dz / len;
  const perpZ = -dx / len;

  const off = seg.laneOffset;
  const startPt = new THREE.Vector3(pFrom.x + perpX * off, 0, pFrom.z + perpZ * off);
  const endPt   = new THREE.Vector3(pTo.x + perpX * off,   0, pTo.z + perpZ * off);

  return [startPt, endPt];
}

// Build smooth turning curve between two connected segments at intersection
function buildTurnCurve(segA, segB) {
  const ptsA = getSegmentLaneWaypoints(segA);
  const ptsB = getSegmentLaneWaypoints(segB);
  const startTurn = ptsA[1];
  const endTurn = ptsB[0];
  
  // Midpoint control point for quadratic bezier turn
  const midPoint = new THREE.Vector3().addVectors(startTurn, endTurn).multiplyScalar(0.5);
  const node = roadNodes[segA.to];
  if (node) {
    midPoint.lerp(new THREE.Vector3(node.x, 0, node.z), 0.4);
  }

  return new THREE.QuadraticBezierCurve3(startTurn, midPoint, endTurn);
}

const vehicles = [];
const vColors = [0x222222,0x555555,0x888888,0xcccccc,0x1a3344,0x334422,0xFFD700,0x0055cc,0xcc2222];

function createVehicle(vType, startSeg) {
  const g = new THREE.Group();
  const col = vType==='taxi'?0xFFD700:vType==='bus'?0x0055cc:vType==='emergency'?0xcc0000:vColors[Math.floor(Math.random()*vColors.length)];
  const bL = vType==='bus'?7.2:4.0, bW = vType==='bus'?2.3:1.8, bH = vType==='bus'?2.2:1.2;
  
  // Tire radius = 0.35, road surface Y = 0.02.
  // Body center Y placed exactly so tires touch the road
  const tireRadius = 0.35;
  const roadY = 0.02;
  const bodyCenterY = roadY + tireRadius + bH / 2;

  const body = new THREE.Mesh(new THREE.BoxGeometry(bW, bH, bL), new THREE.MeshStandardMaterial({color:col, roughness:0.4, metalness:0.3}));
  body.position.y = bodyCenterY;
  body.castShadow = true;
  g.add(body);

  if (vType !== 'bus') {
    const cabH = 0.65;
    const cab = new THREE.Mesh(new THREE.BoxGeometry(bW - 0.25, cabH, bL * 0.45), new THREE.MeshStandardMaterial({color:0x222222, transparent:true, opacity:0.85}));
    cab.position.set(0, bodyCenterY + bH / 2 + cabH / 2, -bL * 0.06);
    g.add(cab);
  }

  const wMat = new THREE.MeshStandardMaterial({color:0x151515, roughness:0.9});
  const wGeo = new THREE.CylinderGeometry(tireRadius, tireRadius, 0.22, 12);
  const wZ = bL * 0.32;
  const wX = bW / 2 + 0.02;
  const wPos = [[-wX, roadY + tireRadius, -wZ], [wX, roadY + tireRadius, -wZ], [-wX, roadY + tireRadius, wZ], [wX, roadY + tireRadius, wZ]];
  const wheels = [];
  wPos.forEach(([wx, wy, wz]) => {
    const w = new THREE.Mesh(wGeo, wMat);
    w.rotation.z = Math.PI / 2;
    w.position.set(wx, wy, wz);
    g.add(w);
    wheels.push(w);
  });

  // Front Headlights (+Z direction of vehicle model)
  const hlMat = new THREE.MeshStandardMaterial({color:0xffffcc, emissive:0xffffcc, emissiveIntensity:1.0});
  [-bW * 0.32, bW * 0.32].forEach(hx => {
    const hl = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), hlMat);
    hl.position.set(hx, bodyCenterY, bL / 2 + 0.02);
    g.add(hl);
  });

  // Rear Taillights (-Z direction of vehicle model)
  const tlMat = new THREE.MeshStandardMaterial({color:0xff2200, emissive:0xff2200, emissiveIntensity:0.8});
  [-bW * 0.32, bW * 0.32].forEach(tx => {
    const tl = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), tlMat);
    tl.position.set(tx, bodyCenterY, -bL / 2 - 0.02);
    g.add(tl);
  });

  // Assign initial route along road segment
  const seg = startSeg || roadSegments[Math.floor(Math.random() * roadSegments.length)];
  const pts = getSegmentLaneWaypoints(seg);
  const initT = initialProgress !== undefined ? initialProgress : Math.random() * 0.8 + 0.1;
  const initPos = new THREE.Vector3().lerpVectors(pts[0], pts[1], initT);
  g.position.copy(initPos);

  // Direction and rotation
  const forwardDir = new THREE.Vector3().subVectors(pts[1], pts[0]).normalize();
  g.rotation.y = angleFromDirection(forwardDir);

  scene.add(g);

  const vData = {
    mesh: g,
    wheels,
    currentSeg: seg,
    segProgress: initT,
    speed: (vType === 'bus' ? 0.12 : 0.16 + Math.random() * 0.10),
    turning: false,
    turnCurve: null,
    turnProgress: 0,
    nextSeg: null
  };

  vehicles.push(vData);
  return g;
}

// ============================================================
// VEHICLE SPAWN MANAGER & TRAFFIC LIMITER
// ============================================================
const MAX_VEHICLES = 18;
const MIN_VEHICLE_DISTANCE = 9.0; // Minimum safe distance in world units between vehicles

// Populate city with optimized number of vehicles (never exceeding MAX_VEHICLES)
const vTypeList = ['car','taxi','car','bus','car','emergency'];
const candidateSegments = roadSegments.filter((_, idx) => idx % 2 === 0);

for(let i = 0; i < Math.min(MAX_VEHICLES, candidateSegments.length); i++) {
  const seg = candidateSegments[i];
  const vType = vTypeList[i % vTypeList.length];
  createVehicle(vType, seg, (i * 0.23) % 0.9 + 0.05);
}

// ============================================================
// PEDESTRIANS — on sidewalks only with realistic population limit
// ============================================================
const MAX_PEDESTRIANS = 14;
const pedestrians = [];
const swZones = [
  { xMin: 14, xMax: 85, zMin: 8.5, zMax: 10.5, axis: 'x' },
  { xMin: 14, xMax: 85, zMin: -10.5, zMax: -8.5, axis: 'x' },
  { xMin: -85, xMax: -14, zMin: 8.5, zMax: 10.5, axis: 'x' },
  { xMin: -85, xMax: -14, zMin: -10.5, zMax: -8.5, axis: 'x' },
  { xMin: 8.5, xMax: 10.5, zMin: -85, zMax: 85, axis: 'z' },
  { xMin: -10.5, xMax: -8.5, zMin: -85, zMax: 85, axis: 'z' },
];
const pedBodyColors = [0x3366cc, 0xcc3333, 0x33cc55, 0xcc9933, 0x9933cc, 0xff6633];

function createPedestrian(zone, initialProgress) {
  if (pedestrians.length >= MAX_PEDESTRIANS) return null;
  const g = new THREE.Group();
  const bMat = new THREE.MeshStandardMaterial({ color: pedBodyColors[Math.floor(Math.random() * pedBodyColors.length)] });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 1.5, 8), bMat);
  body.position.y = 0.75;
  body.castShadow = true;
  g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffccaa }));
  head.position.y = 1.7;
  g.add(head);

  const t = initialProgress !== undefined ? initialProgress : Math.random();
  let sx, sz;
  if (zone.axis === 'x') {
    sx = zone.xMin + t * (zone.xMax - zone.xMin);
    sz = (zone.zMin + zone.zMax) / 2;
  } else {
    sx = (zone.xMin + zone.xMax) / 2;
    sz = zone.zMin + t * (zone.zMax - zone.zMin);
  }

  g.position.set(sx, 0, sz);
  scene.add(g);
  pedestrians.push({
    mesh: g,
    zone,
    speed: 0.022 + Math.random() * 0.018,
    dir: Math.random() > 0.5 ? 1 : -1,
    walkOffset: Math.random() * Math.PI * 2
  });
  return g;
}

// Evenly distribute pedestrians across sidewalk zones without overlapping
swZones.forEach((zone, zIdx) => {
  const countInZone = zIdx < 2 ? 3 : 2;
  for (let i = 0; i < countInZone; i++) {
    if (pedestrians.length < MAX_PEDESTRIANS) {
      createPedestrian(zone, (i + 0.5) / countInZone);
    }
  }
});

// CLOUDS
const clouds=[];
function createCloud(x,y,z,s){
  const g=new THREE.Group();g.position.set(x,y,z);g.scale.setScalar(s||1);
  const cMat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:1,transparent:true,opacity:0.78});
  for(let i=0;i<5+Math.floor(Math.random()*5);i++){
    const p=new THREE.Mesh(new THREE.SphereGeometry(3+Math.random()*3.5,8,6),cMat);
    p.position.set((Math.random()-0.5)*9,(Math.random()-0.5)*2.5,(Math.random()-0.5)*5);
    p.scale.y=0.55;g.add(p);
  }
  scene.add(g);clouds.push({mesh:g,speed:0.012+Math.random()*0.018});
}
for(let i=0;i<18;i++) createCloud((Math.random()-0.5)*400,60+Math.random()*45,(Math.random()-0.5)*250,0.8+Math.random()*1.4);

// STREET LIGHTS along main road sidewalks
const streetLights=[];
function createStreetLight(x,z){
  const g=new THREE.Group();g.position.set(x,0,z);
  const poleMat=new THREE.MeshStandardMaterial({color:0x444444});
  const pole=new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.18,6.5,8),poleMat);
  pole.position.y=3.25;g.add(pole);
  const arm=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.1,2.2),poleMat);
  arm.position.set(0,6.3,1);g.add(arm);
  const lampMat=new THREE.MeshStandardMaterial({color:0xffffaa,emissive:0xffffaa,emissiveIntensity:0});
  const lamp=new THREE.Mesh(new THREE.SphereGeometry(0.28,8,8),lampMat);
  lamp.position.set(0,6.1,2);g.add(lamp);
  const sl=new THREE.PointLight(0xffffaa,0,18);
  sl.position.set(0,5.8,2);g.add(sl);
  scene.add(g);streetLights.push({mesh:g,lampMat,light:sl});
}
for(let i=-80;i<=80;i+=22){createStreetLight(i,13);createStreetLight(i,-13);}

// LIGHTHOUSE
const lhG=new THREE.Group();lhG.position.set(-90,0,-65);
const lhBase=new THREE.Mesh(new THREE.CylinderGeometry(4,5,3,16),new THREE.MeshStandardMaterial({color:0x888888}));
lhBase.position.y=1.5;lhBase.castShadow=true;lhG.add(lhBase);
const lhTower=new THREE.Mesh(new THREE.CylinderGeometry(2,3.5,22,16),new THREE.MeshStandardMaterial({color:0xffffff}));
lhTower.position.y=14;lhTower.castShadow=true;lhG.add(lhTower);
for(let i=0;i<3;i++){const s=new THREE.Mesh(new THREE.CylinderGeometry(2.06,2.06,2.2,16),new THREE.MeshStandardMaterial({color:0xcc0000}));s.position.y=6+i*7;lhG.add(s);}
const lhLanternMat=new THREE.MeshStandardMaterial({color:0xffffaa,emissive:0xffffaa,emissiveIntensity:1.2,transparent:true,opacity:0.82});
const lhLantern=new THREE.Mesh(new THREE.CylinderGeometry(2.5,2.2,3,16),lhLanternMat);
lhLantern.position.y=26.5;lhG.add(lhLantern);
const lhBeamGeo=new THREE.ConeGeometry(9,65,32,1,true);
const lhBeam=new THREE.Mesh(lhBeamGeo,new THREE.MeshBasicMaterial({color:0xffffaa,transparent:true,opacity:0.08,side:THREE.DoubleSide}));
lhBeam.position.set(0,26.5,32);lhBeam.rotation.x=Math.PI/2;lhG.add(lhBeam);
const lhLight=new THREE.PointLight(0xffffaa,2.5,120);lhLight.position.y=26.5;lhG.add(lhLight);
scene.add(lhG);

// BRIDGE
const bridge=new THREE.Mesh(new THREE.BoxGeometry(9,1,65),new THREE.MeshStandardMaterial({color:0x666666}));
bridge.position.set(48,8,-55);bridge.castShadow=true;scene.add(bridge);
for(let i=0;i<4;i++){const sup=new THREE.Mesh(new THREE.CylinderGeometry(1,1.5,10,8),new THREE.MeshStandardMaterial({color:0x888888}));sup.position.set(48,3,-75+i*16);scene.add(sup);}

// BOATS
const boats=[];
function createBoat(x,z,type){
  const g=new THREE.Group();g.position.set(x,-0.5,z);
  if(type==='yacht'){
    const h=new THREE.Mesh(new THREE.BoxGeometry(4,1.5,10),new THREE.MeshStandardMaterial({color:0xffffff}));
    h.position.y=0.5;h.castShadow=true;g.add(h);
    const c=new THREE.Mesh(new THREE.BoxGeometry(2.8,1.5,4),new THREE.MeshStandardMaterial({color:0xeeeeee}));
    c.position.set(0,2,-1);g.add(c);
  } else if(type==='fishing'){
    const h=new THREE.Mesh(new THREE.BoxGeometry(2.2,1.2,5.5),new THREE.MeshStandardMaterial({color:0x8B4513}));
    h.position.y=0.4;h.castShadow=true;g.add(h);
    const m=new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,6,8),new THREE.MeshStandardMaterial({color:0x5c4033}));
    m.position.set(0,3.5,0);g.add(m);
  } else {
    const h=new THREE.Mesh(new THREE.BoxGeometry(9,4,22),new THREE.MeshStandardMaterial({color:0xcc0000}));
    h.position.y=1;h.castShadow=true;g.add(h);
    const cC=[0xcc0000,0x00aa00,0x0000cc,0xaaaa00];
    for(let i=0;i<6;i++){const c=new THREE.Mesh(new THREE.BoxGeometry(3.5,2.5,4.5),new THREE.MeshStandardMaterial({color:cC[i%4]}));c.position.set(0,4.5,-6+i*3.5);c.castShadow=true;g.add(c);}
  }
  scene.add(g);boats.push({mesh:g,type,speed:0.025+Math.random()*0.025,angle:Math.random()*Math.PI*2});
  return g;
}
createBoat(25,-90,'yacht');createBoat(-12,-100,'fishing');createBoat(55,-130,'cargo');createBoat(-45,-80,'yacht');createBoat(15,-110,'fishing');

// BIRDS
const birds=[];
function createBird(){
  const g=new THREE.Group();
  const body=new THREE.Mesh(new THREE.ConeGeometry(0.1,0.5,4),new THREE.MeshStandardMaterial({color:0xffffff}));
  body.rotation.z=Math.PI/2;g.add(body);
  const wing=new THREE.Mesh(new THREE.PlaneGeometry(0.75,0.18),new THREE.MeshStandardMaterial({color:0xdddddd,side:THREE.DoubleSide}));
  wing.position.y=0.1;g.add(wing);
  scene.add(g);
  birds.push({mesh:g,center:new THREE.Vector3((Math.random()-0.5)*120,30+Math.random()*25,(Math.random()-0.5)*120),radius:12+Math.random()*18,speed:0.004+Math.random()*0.008,angle:Math.random()*Math.PI*2,height:30+Math.random()*20});
}
for(let i=0;i<14;i++) createBird();

// RAIN
const rainGeo=new THREE.BufferGeometry();
const rainArr=new Float32Array(6000*3);
for(let i=0;i<6000*3;i+=3){rainArr[i]=(Math.random()-0.5)*350;rainArr[i+1]=Math.random()*220;rainArr[i+2]=(Math.random()-0.5)*350;}
rainGeo.setAttribute('position',new THREE.BufferAttribute(rainArr,3));
const rainMat=new THREE.PointsMaterial({color:0x9999bb,size:0.25,transparent:true,opacity:0});
const rain=new THREE.Points(rainGeo,rainMat);scene.add(rain);

// EVACUATION ROUTES
const evacuationRoutes=[];
function createEvacRoute(pts){
  const geo=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),60,0.28,8,false);
  const mat=new THREE.MeshStandardMaterial({color:0x00ff66,emissive:0x00ff66,emissiveIntensity:1,transparent:true,opacity:0});
  const tube=new THREE.Mesh(geo,mat);scene.add(tube);evacuationRoutes.push(mat);return tube;
}
createEvacRoute([new THREE.Vector3(-90,0.5,-65),new THREE.Vector3(-60,0.5,-40),new THREE.Vector3(-30,0.5,-10),new THREE.Vector3(0,0.5,20),new THREE.Vector3(30,0.5,50)]);
createEvacRoute([new THREE.Vector3(0,0.5,0),new THREE.Vector3(20,0.5,25),new THREE.Vector3(50,0.5,50),new THREE.Vector3(80,0.5,75)]);

// FIRE
const fireParticles=[],smokeParticles=[];
function createFireSystem(x,y,z){
  const fg=new THREE.Group();fg.position.set(x,y,z);
  for(let i=0;i<25;i++){const fMat=new THREE.MeshBasicMaterial({color:new THREE.Color().setHSL(0.04+Math.random()*0.08,1,0.5),transparent:true,opacity:0.8});const f=new THREE.Mesh(new THREE.SphereGeometry(0.3+Math.random()*0.4,6,6),fMat);f.position.set((Math.random()-0.5)*2.5,Math.random()*2,(Math.random()-0.5)*2.5);fg.add(f);fireParticles.push({mesh:f,mat:fMat,baseY:f.position.y,speed:0.02+Math.random()*0.03});}
  for(let i=0;i<18;i++){const sMat=new THREE.MeshBasicMaterial({color:0x333333,transparent:true,opacity:0.3});const s=new THREE.Mesh(new THREE.SphereGeometry(0.5+Math.random()*0.8,6,6),sMat);s.position.set((Math.random()-0.5)*3.5,2+Math.random()*3,(Math.random()-0.5)*3.5);fg.add(s);smokeParticles.push({mesh:s,mat:sMat,baseY:s.position.y,speed:0.012+Math.random()*0.018});}
  fg.visible=false;scene.add(fg);return fg;
}
const fireSystems=[createFireSystem(15,0,20),createFireSystem(-28,0,38),createFireSystem(45,0,-10)];

// TRAFFIC LIGHTS at intersections
const trafficLights=[];
function createTrafficLight(x,z){
  const g=new THREE.Group();g.position.set(x,0,z);
  const poleMat=new THREE.MeshStandardMaterial({color:0x333333});
  const pole=new THREE.Mesh(new THREE.CylinderGeometry(0.1,0.1,5.5,8),poleMat);
  pole.position.y=2.75;g.add(pole);
  const box=new THREE.Mesh(new THREE.BoxGeometry(0.6,1.6,0.4),new THREE.MeshStandardMaterial({color:0x222222}));
  box.position.set(0,5.5,0.3);g.add(box);
  const rMat=new THREE.MeshStandardMaterial({color:0xff0000,emissive:0xff0000,emissiveIntensity:1});
  const yMat=new THREE.MeshStandardMaterial({color:0xffff00,emissive:0xffff00,emissiveIntensity:0.15});
  const gMat=new THREE.MeshStandardMaterial({color:0x00ff00,emissive:0x00ff00,emissiveIntensity:0.15});
  const rL=new THREE.Mesh(new THREE.SphereGeometry(0.14,8,8),rMat);rL.position.set(0,5.85,0.52);g.add(rL);
  const yL=new THREE.Mesh(new THREE.SphereGeometry(0.14,8,8),yMat);yL.position.set(0,5.5,0.52);g.add(yL);
  const gL=new THREE.Mesh(new THREE.SphereGeometry(0.14,8,8),gMat);gL.position.set(0,5.15,0.52);g.add(gL);
  scene.add(g);trafficLights.push({mesh:g,redMat:rMat,yellowMat:yMat,greenMat:gMat,state:0,timer:Math.random()*200});
}
[[9,9],[-9,9],[9,-9],[-9,-9],[9,40],[-9,40],[9,-40],[-9,-40],[9,80],[-9,80],[60,9],[-60,9],[60,-9],[-60,-9],[60,40],[-60,40]].forEach(([ix,iz])=>createTrafficLight(ix,iz));

// MINI GLOBE
const globeContainer=document.getElementById('mini-globe');
const globeScene=new THREE.Scene(),globeCamera=new THREE.PerspectiveCamera(45,1,0.1,100);
globeCamera.position.set(0,0,3);
const globeRenderer=new THREE.WebGLRenderer({alpha:true,antialias:true});
globeRenderer.setSize(110,110);globeRenderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
globeContainer.appendChild(globeRenderer.domElement);
const globe=new THREE.Mesh(new THREE.SphereGeometry(1,32,32),new THREE.MeshBasicMaterial({color:0x1a5f7a,wireframe:true,transparent:true,opacity:0.65}));
globeScene.add(globe);
const land=new THREE.Mesh(new THREE.SphereGeometry(0.98,32,32),new THREE.MeshBasicMaterial({color:0x4a7c59,wireframe:true,transparent:true,opacity:0.3}));
globeScene.add(land);
const cityMarker=new THREE.Mesh(new THREE.SphereGeometry(0.05,8,8),new THREE.MeshBasicMaterial({color:0xC8A96B}));
cityMarker.position.set(0.3,0.5,0.8);globeScene.add(cityMarker);
const gL1=new THREE.DirectionalLight(0xffffff,1.2);gL1.position.set(-2,2,2);globeScene.add(gL1);
const gL2=new THREE.DirectionalLight(0xffffff,1.2);gL2.position.set(2,2,2);globeScene.add(gL2);

// DAY/NIGHT CYCLE
function updateDayNightCycle(t){
  const frac=t/24;
  const sunAngle=(frac-0.25)*Math.PI*2;
  sunLight.position.x=Math.cos(sunAngle)*120;
  sunLight.position.y=Math.sin(sunAngle)*120;
  sunLight.position.z=60;
  const isDay=t>6&&t<18;
  const isSunset=(t>17&&t<19.5)||(t>4.5&&t<7);
  if(isDay){
    const di=Math.sin(((t-6)/12)*Math.PI);
    sunLight.intensity=di*1.7;ambientLight.intensity=0.28+di*0.32;
    skyMat.color.setHex(isSunset?C.sunsetSky:C.daySky);
    hemiLight.color.setHex(isSunset?C.sunsetSky:C.daySky);
    starsMat.opacity=0;moonLight.visible=false;
    streetLights.forEach(sl=>{sl.lampMat.emissiveIntensity=0;sl.light.intensity=0;});
    buildingLights.forEach(m=>{m.emissiveIntensity=0.08;});
  } else {
    sunLight.intensity=0;ambientLight.intensity=0.08;
    skyMat.color.setHex(C.nightSky);hemiLight.color.setHex(0x1a1a3e);
    const np=1-Math.abs(t-12)/12;
    starsMat.opacity=Math.min(1,np*0.9);moonLight.visible=true;
    streetLights.forEach(sl=>{sl.lampMat.emissiveIntensity=1.2;sl.light.intensity=1.4;});
    buildingLights.forEach(m=>{if(Math.random()<0.01) m.emissiveIntensity=0.4+Math.random()*0.4;});
  }
  scene.fog.density=THREE.MathUtils.lerp(scene.fog.density,isDay?0.0018:0.004,0.01);
}

function updateWeather(w){
  switch(w){
    case 'sunny':rainMat.opacity=0;scene.fog.density=0.0018;bloomPass.strength=0.35;break;
    case 'cloudy':rainMat.opacity=0;scene.fog.density=0.004;bloomPass.strength=0.22;break;
    case 'rain':rainMat.opacity=0.65;scene.fog.density=0.006;bloomPass.strength=0.14;break;
    case 'storm':rainMat.opacity=0.92;scene.fog.density=0.009;bloomPass.strength=0.1;break;
    case 'fog':rainMat.opacity=0;scene.fog.density=0.018;bloomPass.strength=0.08;break;
    case 'wind':rainMat.opacity=0;scene.fog.density=0.0025;bloomPass.strength=0.28;break;
  }
}

const cameraModes={
  orbit:{pos:new THREE.Vector3(90,65,90),target:new THREE.Vector3(0,0,0)},
  drone:{pos:new THREE.Vector3(0,170,10),target:new THREE.Vector3(0,0,0)},
  street:{pos:new THREE.Vector3(-35,2.5,3),target:new THREE.Vector3(100,2.5,3)},
  cinematic:{pos:new THREE.Vector3(150,35,-110),target:new THREE.Vector3(-15,10,20)},
};

const camTransition={
  active:false,
  startPos:new THREE.Vector3(),
  endPos:new THREE.Vector3(),
  startTarget:new THREE.Vector3(),
  endTarget:new THREE.Vector3(),
  duration:1.4,
  elapsed:0,
  onComplete:null
};

function setCameraMode(mode){
  state.cameraMode=mode;
  const cfg=cameraModes[mode];if(!cfg) return;
  camTransition.startPos.copy(camera.position);
  camTransition.endPos.copy(cfg.pos);
  camTransition.startTarget.copy(controls.target);
  camTransition.endTarget.copy(cfg.target);
  camTransition.duration=1.4;
  camTransition.elapsed=0;
  camTransition.active=true;
  camTransition.onComplete=()=>{
    camera.position.copy(cfg.pos);
    controls.target.copy(cfg.target);
  };
}

function playIntro(){
  camera.position.set(220,160,220);
  controls.target.set(0,0,0);
  camTransition.startPos.set(220,160,220);
  camTransition.endPos.set(80,60,80);
  camTransition.startTarget.set(0,0,0);
  camTransition.endTarget.set(0,5,0);
  camTransition.duration=3.2;
  camTransition.elapsed=0;
  camTransition.active=true;
  camTransition.onComplete=()=>{
    state.introComplete=true;
  };
}

function updateCameraTransition(delta){
  if(!camTransition.active) return;
  camTransition.elapsed += delta;
  const progress = Math.min(camTransition.elapsed / camTransition.duration, 1);
  // Smooth cubic ease out
  const t = 1 - Math.pow(1 - progress, 3);
  camera.position.lerpVectors(camTransition.startPos, camTransition.endPos, t);
  controls.target.lerpVectors(camTransition.startTarget, camTransition.endTarget, t);
  if(progress >= 1){
    camTransition.active = false;
    if(camTransition.onComplete) camTransition.onComplete();
  }
}

// AI PREDICTION
const AIPrediction={
  risks:{flood:12,storm:8,traffic:34,heat:5},
  update(){
    const{time:t,weather:w}=state;
    let fr=5;if(w==='rain')fr+=25;if(w==='storm')fr+=48;if(t>18||t<6)fr+=10;if(state.floodLevel>5)fr+=22;
    let sr=3;if(w==='cloudy')sr+=15;if(w==='rain')sr+=32;if(w==='storm')sr+=58;
    let tr=20;if(t>7&&t<9)tr+=30;if(t>17&&t<19)tr+=25;if(w==='rain')tr+=15;
    let hr=2;if(t>11&&t<15)hr+=20;if(w==='sunny')hr+=15;
    this.risks.flood=Math.min(95,Math.max(0,fr+(Math.random()-0.5)*4));
    this.risks.storm=Math.min(95,Math.max(0,sr+(Math.random()-0.5)*3));
    this.risks.traffic=Math.min(95,Math.max(0,tr+(Math.random()-0.5)*5));
    this.risks.heat=Math.min(95,Math.max(0,hr+(Math.random()-0.5)*2));
    this.updateUI();this.checkAlerts();
  },
  updateUI(){
    const set=(id,val)=>{
      const el=document.getElementById(id+'-risk-val'),bar=document.getElementById(id+'-risk-bar');
      if(!el||!bar) return;
      el.textContent=Math.round(val)+'%';bar.style.width=val+'%';
      el.className='risk-value '+(val<30?'risk-low':val<60?'risk-med':'risk-high');
      bar.className='risk-bar-fill '+(val<30?'fill-low':val<60?'fill-med':'fill-high');
    };
    set('flood',this.risks.flood);set('storm',this.risks.storm);set('traffic',this.risks.traffic);set('heat',this.risks.heat);
    const p24=document.getElementById('pred-24h'),p48=document.getElementById('pred-48h'),p72=document.getElementById('pred-72h');
    if(this.risks.flood>50){p24.textContent='Flood warning active';p48.textContent='Severe flooding expected';p72.textContent='Critical: Evacuate coastal zones';}
    else if(this.risks.storm>40){p24.textContent='Storm approaching';p48.textContent='High winds expected';p72.textContent='Storm surge warning';}
    else{p24.textContent='Low risk period';p48.textContent='Moderate tide expected';p72.textContent='No significant threats';}
  },
  checkAlerts(){
    const b=document.getElementById('alert-banner'),badge=document.getElementById('alert-badge'),txt=document.getElementById('alert-text');
    if(this.risks.flood>60||this.risks.storm>60){
      b.classList.add('show');badge.classList.add('active');
      txt.textContent=this.risks.flood>this.risks.storm?`DISASTER ALERT: Flood risk ${Math.round(this.risks.flood)}%`:`DISASTER ALERT: Storm risk ${Math.round(this.risks.storm)}%`;
    } else {b.classList.remove('show');badge.classList.remove('active');}
  }
};

const Analytics={
  update(){
    const t=state.time,w=state.weather;
    let pop=142000;if(t>7&&t<10)pop+=18000;if(t>11&&t<14)pop+=25000;if(t>17&&t<20)pop+=20000;if(t>22||t<5)pop-=28000;
    const popEl=document.getElementById('metric-pop');if(popEl)popEl.textContent=Math.floor(pop+(Math.random()-0.5)*1500).toLocaleString();
    let traffic=8400;if(t>7&&t<9)traffic+=3200;if(t>17&&t<19)traffic+=2800;
    const tfEl=document.getElementById('metric-traffic');if(tfEl)tfEl.textContent=Math.floor(traffic+(Math.random()-0.5)*300).toLocaleString();
    const pedEl=document.getElementById('metric-peds');if(pedEl)pedEl.textContent=`${pedestrians.length} Active`;
    let aqi=38;if(w==='fog')aqi+=18;if(w==='storm')aqi-=12;if(state.fireSimulation)aqi+=75;
    const aqiEl=document.getElementById('metric-aqi');if(aqiEl)aqiEl.textContent='AQI '+Math.floor(aqi+(Math.random()-0.5)*4);
    
    // Update live bottom HUD and traffic cards
    const vCountEl=document.getElementById('stat-veh-count');if(vCountEl)vCountEl.textContent=vehicles.length;
    const botVEl=document.getElementById('stat-active-v');if(botVEl)botVEl.textContent=vehicles.length;
    const botPEl=document.getElementById('stat-active-p');if(botPEl)botPEl.textContent=pedestrians.length;
    
    // Average speed from vehicles
    if(vehicles.length>0){
      const avgSpd = Math.round(vehicles.reduce((acc,v)=>acc+(v.speed*180),0)/vehicles.length);
      const spdEl=document.getElementById('stat-avg-speed');if(spdEl)spdEl.textContent=`${avgSpd} km/h`;
    }
  }
};

const AIAssistant={
  sendMessage(text){
    const c=document.getElementById('ai-chat-messages');
    const um=document.createElement('div');um.className='ai-message user';um.textContent=text;c.appendChild(um);c.scrollTop=c.scrollHeight;
    setTimeout(()=>{const bm=document.createElement('div');bm.className='ai-message bot';bm.textContent=this.respond(text);c.appendChild(bm);c.scrollTop=c.scrollHeight;},500+Math.random()*400);
  },
  respond(input){
    const l=input.toLowerCase();
    if(l.includes('flood')||l.includes('water')) return `Flood risk: ${Math.round(AIPrediction.risks.flood)}%. ${AIPrediction.risks.flood>50?'Evacuate coastal zones!':'Conditions stable.'}`;
    if(l.includes('storm')||l.includes('weather')) return `Storm risk: ${Math.round(AIPrediction.risks.storm)}%. ${AIPrediction.risks.storm>40?'Storm developing.':'Weather calm.'}`;
    if(l.includes('3d')||l.includes('hunyuan')||l.includes('camera')) return 'Click the "OPEN CAMERA to 3D" button! It opens your laptop camera and uses Hunyuan3D-2 on port 9000 to convert 2D photos to 3D models instantly.';
    if(l.includes('grid')||l.includes('road')) return 'Phase 3 grid layout: vehicles locked to lane Z/X coordinates, buildings only in city blocks, park zone at x=65-125/z=15-85. Zero overlap!';
    if(l.includes('help')||l.includes('hello')) return 'Phase 3: Grid city, vehicle lanes, park zone, Hunyuan3D-2. Compare old phase 2 localhost vs this new localhost side by side!';
    return `Digital Twin grid city: ${vehicles.length} vehicles actively navigating ${roadSegments.length} road network lanes and intersections, ${buildings.length} buildings in city blocks. All aligned perfectly!`;
  }
};

function updateFloodSimulation(){
  if(state.floodLevel>0){floodWater.visible=true;floodWater.position.y=state.floodLevel-1.5;floodMat.opacity=Math.min(0.88,0.4+state.floodLevel*0.022);}
  else floodWater.visible=false;
}

// UI EVENTS
document.getElementById('time-slider').addEventListener('input',e=>{state.time=parseFloat(e.target.value);state.autoTime=false;document.getElementById('auto-time-toggle').classList.remove('active');updateTimeDisplay();});
function updateTimeDisplay(){
  const h=Math.floor(state.time),m=Math.floor((state.time%1)*60);
  const ampm=h>=12?'PM':'AM',dh=h%12||12;
  const ts=dh+':'+m.toString().padStart(2,'0')+' '+ampm;
  document.getElementById('time-display').textContent=ts;
  document.getElementById('stat-time').textContent=ts;
  document.getElementById('current-time-label').textContent=['Midnight','Dawn','Morning','Noon','Afternoon','Sunset','Evening','Night'][Math.min(Math.floor(state.time/3),7)];
}
document.querySelectorAll('.weather-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.weather-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
    state.weather=btn.dataset.weather;document.getElementById('stat-weather').textContent=btn.dataset.weather.charAt(0).toUpperCase()+btn.dataset.weather.slice(1);
    updateWeather(state.weather);
  });
});
document.querySelectorAll('.camera-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{document.querySelectorAll('.camera-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');setCameraMode(btn.dataset.camera);});
});
document.getElementById('auto-time-toggle').addEventListener('click',function(){this.classList.toggle('active');state.autoTime=this.classList.contains('active');});
document.getElementById('traffic-toggle').addEventListener('click',function(){this.classList.toggle('active');state.trafficEnabled=this.classList.contains('active');});
document.getElementById('pedestrians-toggle').addEventListener('click',function(){this.classList.toggle('active');state.pedestriansEnabled=this.classList.contains('active');});
document.getElementById('flood-slider').addEventListener('input',e=>{state.floodLevel=parseFloat(e.target.value);document.getElementById('flood-level-label').textContent='Water Level: '+state.floodLevel.toFixed(1)+'m';updateFloodSimulation();});
document.getElementById('evac-toggle').addEventListener('click',function(){this.classList.toggle('active');state.showEvacuation=this.classList.contains('active');evacuationRoutes.forEach(m=>{m.opacity=state.showEvacuation?0.85:0;});});
document.getElementById('auto-flood-toggle').addEventListener('click',function(){this.classList.toggle('active');state.autoFlood=this.classList.contains('active');});
document.getElementById('earthquake-slider').addEventListener('input',e=>{state.earthquakeIntensity=parseFloat(e.target.value);document.getElementById('earthquake-label').textContent='Earthquake: '+state.earthquakeIntensity.toFixed(1)+' Richter';});
document.getElementById('fire-sim-btn').addEventListener('click',()=>{state.fireSimulation=!state.fireSimulation;document.getElementById('fire-sim-btn').style.background=state.fireSimulation?'rgba(204,51,51,0.32)':'';fireSystems.forEach(s=>s.visible=state.fireSimulation);});
document.getElementById('quake-sim-btn').addEventListener('click',()=>{state.earthquakeIntensity=7.5;document.getElementById('earthquake-slider').value=7.5;document.getElementById('earthquake-label').textContent='Earthquake: 7.5 Richter';setTimeout(()=>{state.earthquakeIntensity=0;document.getElementById('earthquake-slider').value=0;document.getElementById('earthquake-label').textContent='Earthquake: 0.0 Richter';},5000);});
document.getElementById('photo-mode-btn').addEventListener('click',()=>{state.photoMode=true;document.getElementById('photo-mode-overlay').classList.add('active');document.getElementById('ui-overlay').style.opacity='0';document.getElementById('ui-overlay').style.pointerEvents='none';});
document.getElementById('photo-exit').addEventListener('click',()=>{state.photoMode=false;document.getElementById('photo-mode-overlay').classList.remove('active');document.getElementById('ui-overlay').style.opacity='1';document.getElementById('ui-overlay').style.pointerEvents='auto';});
document.getElementById('photo-capture').addEventListener('click',()=>{renderer.render(scene,camera);const link=document.createElement('a');link.download='coastal-city-phase3-'+Date.now()+'.png';link.href=renderer.domElement.toDataURL('image/png');link.click();});
// ============================================================
// AI TRAFFIC INCIDENT SIMULATION & ADAPTIVE SIGNALS
// ============================================================
let activeTrafficIncident = null;

window.simulateTrafficIncident = function(){
  if(activeTrafficIncident) return;
  
  // Pick a central road segment for incident demo
  const targetSeg = roadSegments.find(s => s.id === 'EW0_2') || roadSegments[0];
  const pts = getSegmentLaneWaypoints(targetSeg);
  const midPos = new THREE.Vector3().lerpVectors(pts[0], pts[1], 0.5);

  // Create visual incident beacon
  const incGroup = new THREE.Group();
  incGroup.position.copy(midPos);
  const flare = new THREE.Mesh(
    new THREE.ConeGeometry(0.8, 2.0, 8),
    new THREE.MeshStandardMaterial({color:0xff3300, emissive:0xff3300, emissiveIntensity:1.5})
  );
  flare.position.y = 1.0;
  incGroup.add(flare);
  scene.add(incGroup);

  activeTrafficIncident = {
    group: incGroup,
    segmentId: targetSeg.id,
    pos: midPos
  };

  // AI Traffic Engine Dynamic Response Steps
  const logEl = document.getElementById('ai-traffic-log');
  const congEl = document.getElementById('stat-congestion');
  const congStatEl = document.getElementById('stat-active-cong');
  const alertBanner = document.getElementById('alert-banner');
  const alertTxt = document.getElementById('alert-text');

  if(logEl) logEl.innerHTML = `⚠️ <b style="color:#ef4444;">INCIDENT DETECTED:</b> Sector EW-Main<br>● AI analyzing traffic flow...`;
  if(congEl) { congEl.textContent = 'HIGH'; congEl.style.color = '#ef4444'; }
  if(congStatEl) { congStatEl.textContent = 'Congested'; congStatEl.style.color = '#ef4444'; }
  if(alertBanner && alertTxt) {
    alertBanner.classList.add('show');
    alertTxt.textContent = 'AI TRAFFIC ALERT: Incident on EW-Main Corridor. Rerouting traffic.';
  }

  // Step 2: Alternate route calculated
  setTimeout(()=>{
    if(logEl) logEl.innerHTML = `⚠️ <b style="color:#f59e0b;">AI CALCULATING:</b> Alternate bypass route<br>● Rerouting vehicles to Secondary EW-40`;
    // Smart traffic lights adjust: lengthen green on bypass
    trafficLights.forEach((tl, idx) => {
      if(idx % 2 === 0) tl.state = 2; // Green
    });
  }, 2200);

  // Step 3: Traffic flow optimized
  setTimeout(()=>{
    if(logEl) logEl.innerHTML = `✅ <b style="color:#10b981;">FLOW OPTIMIZED:</b> Congestion cleared<br>● Traffic signal timings adapted via AI`;
    if(congEl) { congEl.textContent = 'LOW'; congEl.style.color = '#10b981'; }
    if(congStatEl) { congStatEl.textContent = 'Optimum'; congStatEl.style.color = '#10b981'; }
  }, 5000);

  // Step 4: Resolve incident after 8 seconds
  setTimeout(()=>{
    if(activeTrafficIncident){
      scene.remove(activeTrafficIncident.group);
      activeTrafficIncident = null;
    }
    if(alertBanner) alertBanner.classList.remove('show');
    if(logEl) logEl.innerHTML = `● AI Traffic Engine: Active<br>● Dynamic lane optimization synced<br>● Road networks flowing normally`;
  }, 8000);
};

document.getElementById('reset-btn').addEventListener('click',()=>{
  state.time=12;state.weather='sunny';state.floodLevel=0;state.earthquakeIntensity=0;state.fireSimulation=false;state.autoFlood=false;state.showEvacuation=false;
  document.getElementById('time-slider').value=12;document.getElementById('flood-slider').value=0;document.getElementById('earthquake-slider').value=0;
  document.querySelectorAll('.weather-btn').forEach(b=>b.classList.remove('active'));document.querySelector('[data-weather="sunny"]').classList.add('active');
  document.querySelectorAll('.camera-btn').forEach(b=>b.classList.remove('active'));document.querySelector('[data-camera="orbit"]').classList.add('active');
  setCameraMode('orbit');updateTimeDisplay();updateWeather('sunny');updateFloodSimulation();fireSystems.forEach(s=>s.visible=false);
  
  if(activeTrafficIncident){
    scene.remove(activeTrafficIncident.group);
    activeTrafficIncident = null;
  }

  // Reset vehicles cleanly to valid road segments
  vehicles.forEach((v, idx) => {
    v.turning = false;
    v.turnCurve = null;
    v.turnProgress = 0;
    v.currentSeg = roadSegments[idx % roadSegments.length];
    v.segProgress = (idx * 0.17) % 1.0;
    const pts = getSegmentLaneWaypoints(v.currentSeg);
    v.mesh.position.lerpVectors(pts[0], pts[1], v.segProgress);
    v.mesh.position.y = 0;
    const dir = new THREE.Vector3().subVectors(pts[1], pts[0]).normalize();
    v.mesh.rotation.y = angleFromDirection(dir);
  });
});
document.getElementById('fullscreen-btn').addEventListener('click',()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen();else document.exitFullscreen();});
document.getElementById('ai-chat-toggle').addEventListener('click',()=>{document.getElementById('ai-chat-widget').classList.toggle('open');document.getElementById('ai-chat-toggle').classList.toggle('hidden');});
document.getElementById('ai-chat-send').addEventListener('click',()=>{const inp=document.getElementById('ai-chat-input');const txt=inp.value.trim();if(txt){AIAssistant.sendMessage(txt);inp.value='';}});
document.getElementById('ai-chat-input').addEventListener('keypress',e=>{if(e.key==='Enter')document.getElementById('ai-chat-send').click();});
document.addEventListener('click',e=>{const w=document.getElementById('ai-chat-widget');const t=document.getElementById('ai-chat-toggle');if(!w.contains(e.target)&&!t.contains(e.target)&&w.classList.contains('open')){w.classList.remove('open');t.classList.remove('hidden');}});

// ============================================================
// HUNYUAN3D-2 MODAL
// ============================================================
let hmStream=null,hmModelUrl=null;
let hmViewerScene=null,hmViewerRenderer=null,hmViewerCamera=null,hmViewerControls=null,hmAnimId=null;

function initHmViewer(){
  const c=document.getElementById('hm-3d-viewer');
  if(hmViewerRenderer){c.innerHTML='';hmViewerRenderer.dispose();}
  hmViewerScene=new THREE.Scene();hmViewerScene.background=new THREE.Color(0x090912);
  hmViewerCamera=new THREE.PerspectiveCamera(50,c.clientWidth/c.clientHeight,0.01,1000);
  hmViewerCamera.position.set(0,1,3);
  hmViewerRenderer=new THREE.WebGLRenderer({antialias:true});
  hmViewerRenderer.setSize(c.clientWidth,c.clientHeight);hmViewerRenderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  hmViewerRenderer.shadowMap.enabled=true;hmViewerRenderer.toneMapping=THREE.ACESFilmicToneMapping;
  c.appendChild(hmViewerRenderer.domElement);
  hmViewerControls=new OrbitControls(hmViewerCamera,hmViewerRenderer.domElement);
  hmViewerControls.enableDamping=true;hmViewerControls.autoRotate=true;hmViewerControls.autoRotateSpeed=1.2;
  const al=new THREE.AmbientLight(0xffffff,0.6);hmViewerScene.add(al);
  const dl=new THREE.DirectionalLight(0xffffff,1.2);dl.position.set(5,10,5);hmViewerScene.add(dl);
  const dl2=new THREE.DirectionalLight(0x8FA28A,0.6);dl2.position.set(-5,5,-5);hmViewerScene.add(dl2);
  const grid=new THREE.GridHelper(4,10,0x333344,0x222233);grid.position.y=-0.5;hmViewerScene.add(grid);
  function animHm(){hmAnimId=requestAnimationFrame(animHm);hmViewerControls.update();hmViewerRenderer.render(hmViewerScene,hmViewerCamera);}
  animHm();
}

function setHmStatus(msg,type){const el=document.getElementById('hm-status');el.textContent=msg;el.className='hm-status'+(type?' '+type:'');}
function setHmProgress(pct){document.getElementById('hm-progress-fill').style.width=pct+'%';}

function stopHmCamera(){if(hmStream){hmStream.getTracks().forEach(t=>t.stop());hmStream=null;}}

document.getElementById('open-hunyuan-btn').addEventListener('click',()=>{document.getElementById('hunyuan-modal').classList.add('open');initHmViewer();document.getElementById('hm-3d-empty').style.display='flex';});
document.getElementById('hm-close-btn').addEventListener('click',()=>{document.getElementById('hunyuan-modal').classList.remove('open');stopHmCamera();if(hmAnimId)cancelAnimationFrame(hmAnimId);});

document.getElementById('hm-start-cam').addEventListener('click',async()=>{
  try{
    hmStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}});
    const video=document.getElementById('hm-video');
    video.srcObject=hmStream;video.style.display='block';
    document.getElementById('hm-placeholder').style.display='none';
    document.getElementById('hm-snapshot-canvas').style.display='none';
    document.getElementById('hm-uploaded-img').style.display='none';
    document.getElementById('hm-snap-btn').disabled=false;
    setHmStatus('Camera live! Click "Convert to 3D" to capture and convert.','');
    document.getElementById('hm-start-cam').textContent='Camera Active';
  }catch(err){setHmStatus('Camera access denied: '+err.message,'error');}
});

document.getElementById('hm-upload-btn').addEventListener('click',()=>document.getElementById('hm-file-input').click());
document.getElementById('hm-file-input').addEventListener('change',e=>{
  if(e.target.files&&e.target.files[0]){
    const reader=new FileReader();
    reader.onload=ev=>{
      stopHmCamera();
      const img=document.getElementById('hm-uploaded-img');
      img.src=ev.target.result;img.style.display='block';
      document.getElementById('hm-video').style.display='none';
      document.getElementById('hm-placeholder').style.display='none';
      document.getElementById('hm-snapshot-canvas').style.display='none';
      document.getElementById('hm-snap-btn').disabled=false;
      document.getElementById('hm-start-cam').textContent='Start Camera';
      setHmStatus('Image loaded — click "Convert to 3D"!','');
    };
    reader.readAsDataURL(e.target.files[0]);
  }
});

document.getElementById('hm-snap-btn').addEventListener('click',async()=>{
  const snapBtn=document.getElementById('hm-snap-btn');
  snapBtn.disabled=true;
  document.getElementById('hm-download-btn').disabled=true;
  document.getElementById('hm-place-in-city-btn').disabled=true;
  setHmStatus('Capturing image...','processing');setHmProgress(10);

  let base64Image='';
  const video=document.getElementById('hm-video');
  const canvas=document.getElementById('hm-snapshot-canvas');
  const img=document.getElementById('hm-uploaded-img');

  if(hmStream&&video.srcObject){
    canvas.width=video.videoWidth||640;canvas.height=video.videoHeight||480;
    canvas.getContext('2d').drawImage(video,0,0,canvas.width,canvas.height);
    base64Image=canvas.toDataURL('image/jpeg',0.85);
    stopHmCamera();video.style.display='none';canvas.style.display='block';
    document.getElementById('hm-start-cam').textContent='Start Camera';
  } else if(img.style.display!=='none'&&img.src){
    base64Image=img.src;
  } else if(canvas.style.display!=='none'){
    base64Image=canvas.toDataURL('image/jpeg',0.85);
  }

  if(!base64Image){setHmStatus('No image. Start camera or upload first.','error');snapBtn.disabled=false;setHmProgress(0);return;}

  setHmStatus('Sending to Hunyuan3D-2 on port 9000...','processing');setHmProgress(25);

  try{
    const resp=await fetch('http://localhost:9000/api/camera-to-3d',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image:base64Image})});
    setHmProgress(60);
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    const data=await resp.json();setHmProgress(80);
    if(data.model_url||data.glb_url){
      setHmStatus('Loading 3D model...','processing');hmModelUrl=data.model_url||data.glb_url;
      await loadGlbInViewer(hmModelUrl);
      setHmProgress(100);setHmStatus('3D model ready! Drag to rotate. | '+data.processing_time+'s','success');
      document.getElementById('hm-model-info').textContent='Hunyuan3D-2 output: '+( data.filename||'model.glb')+' | Port 9000';
    } else {
      await createDemoModel(data.seed||0.5);setHmProgress(100);
      setHmStatus('Demo mode (install Hunyuan3D-2 for real conversion)','success');
      document.getElementById('hm-model-info').textContent='DEMO: Run python backend/main_phase3.py for real Hunyuan3D-2 conversion';
    }
  } catch(err){
    console.warn('Port 9000 not running, demo mode:',err.message);
    setHmStatus('Port 9000 backend offline. Showing demo 3D model...','processing');setHmProgress(50);
    await new Promise(r=>setTimeout(r,1000));
    await createDemoModel(Math.random());setHmProgress(100);
    setHmStatus('DEMO 3D model ready! Start backend on port 9000 for Hunyuan3D-2.','success');
    document.getElementById('hm-model-info').textContent='DEMO MODE: Run "uvicorn backend.main_phase3:app --port 9000" for real conversion';
  }
  document.getElementById('hm-download-btn').disabled=false;
  document.getElementById('hm-place-in-city-btn').disabled=false;
  snapBtn.disabled=false;
});

async function loadGlbInViewer(url){
  return new Promise((resolve,reject)=>{
    const loader=new GLTFLoader();
    document.getElementById('hm-3d-empty').style.display='none';
    const toRemove=[];hmViewerScene.traverse(o=>{if(o.isMesh&&!o.isGridHelper)toRemove.push(o);});
    toRemove.forEach(o=>hmViewerScene.remove(o));
    loader.load(url,gltf=>{
      const model=gltf.scene;
      const box=new THREE.Box3().setFromObject(model);
      const center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3()).length();
      model.position.sub(center);model.scale.setScalar(2/size);
      hmViewerScene.add(model);
      hmViewerCamera.position.set(0,0.5,2.5);hmViewerControls.target.set(0,0,0);
      resolve();
    },undefined,reject);
  });
}

async function createDemoModel(seed){
  document.getElementById('hm-3d-empty').style.display='none';
  const toRemove=[];hmViewerScene.traverse(o=>{if(o.isMesh)toRemove.push(o);});toRemove.forEach(o=>hmViewerScene.remove(o));
  const floors=Math.floor(4+seed*8);const bH=floors*0.42;
  const body=new THREE.Mesh(new THREE.BoxGeometry(1+seed*0.6,bH,0.8+seed*0.5),new THREE.MeshStandardMaterial({color:0x87CEEB,roughness:0.08,metalness:0.9,transparent:true,opacity:0.75}));
  body.position.y=bH/2;body.castShadow=true;hmViewerScene.add(body);
  for(let f=0;f<floors;f++){for(let c=0;c<3;c++){const w=new THREE.Mesh(new THREE.PlaneGeometry(0.18,0.22),new THREE.MeshStandardMaterial({color:0xffffcc,emissive:0xffffcc,emissiveIntensity:0.8}));w.position.set(-0.4+c*0.32,0.3+f*0.44,(0.8+seed*0.5)/2+0.01);hmViewerScene.add(w);}}
  const roof=new THREE.Mesh(new THREE.BoxGeometry((1+seed*0.6)*0.8,0.08,(0.8+seed*0.5)*0.8),new THREE.MeshStandardMaterial({color:0xC8A96B,metalness:0.6}));roof.position.y=bH+0.04;hmViewerScene.add(roof);
  const ant=new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.5,6),new THREE.MeshStandardMaterial({color:0x888888}));ant.position.y=bH+0.29;hmViewerScene.add(ant);
  const beacon=new THREE.Mesh(new THREE.SphereGeometry(0.04,8,8),new THREE.MeshStandardMaterial({color:0xff0000,emissive:0xff0000,emissiveIntensity:3}));beacon.position.y=bH+0.56;hmViewerScene.add(beacon);
  hmViewerCamera.position.set(0,bH/2,3);hmViewerControls.target.set(0,bH/2,0);
}

document.getElementById('hm-download-btn').addEventListener('click',()=>{
  if(hmModelUrl){const a=document.createElement('a');a.href=hmModelUrl;a.download='hunyuan3d_output.glb';a.click();}
  else{hmViewerRenderer.render(hmViewerScene,hmViewerCamera);const a=document.createElement('a');a.href=hmViewerRenderer.domElement.toDataURL('image/png');a.download='hunyuan3d_preview.png';a.click();}
});

document.getElementById('hm-place-in-city-btn').addEventListener('click',()=>{
  if(hmViewerScene){
    hmViewerScene.traverse(o=>{
      if(o.isMesh){
        const clone=o.clone();
        clone.position.set((Math.random()-0.5)*40,0,20+Math.random()*30);
        clone.scale.setScalar(8+Math.random()*10);
        scene.add(clone);
      }
    });
    document.getElementById('hunyuan-modal').classList.remove('open');
    stopHmCamera();if(hmAnimId)cancelAnimationFrame(hmAnimId);
  }
});

// LOADING
const loadSteps=['Initializing grid-based city layout...','Building road network (N-S + E-W grid)...','Placing buildings in city blocks only...','Adding park zone with fountain, ferris wheel...','Spawning vehicles on road lanes (no building overlap)...','Adding pedestrians to sidewalks only...','Configuring Hunyuan3D-2 pipeline on port 9000...','Loading AI prediction models...','Setting up lighting & weather systems...','Phase 3 — Perfect City Ready!'];
let lp=0;
const lb=document.getElementById('loading-bar'),lt=document.getElementById('loading-text');
function updateLoading(){
  lp+=1.2;lb.style.width=Math.min(lp,100)+'%';
  lt.textContent=loadSteps[Math.min(Math.floor((lp/100)*loadSteps.length),loadSteps.length-1)];
  if(lp<100){setTimeout(updateLoading,55);}
  else{setTimeout(()=>{document.getElementById('loading-screen').classList.add('fade-out');document.getElementById('ui-overlay').style.opacity='1';playIntro();},600);}
}
updateLoading();

// ============================================================
// LANDING PAGE CONTROLLER & CHARACTER-BY-CHARACTER ANIMATION
// ============================================================
function initHeroAnimations(){
  const headingEl = document.getElementById('hero-animated-heading');
  if(headingEl){
    const text = "Simulating tomorrow.\nProtecting today.";
    headingEl.innerHTML = '';
    
    // Character-by-character span generation with stagger
    let charCount = 0;
    for(let i=0; i<text.length; i++){
      const char = text[i];
      if(char === '\n'){
        headingEl.appendChild(document.createElement('br'));
        continue;
      }
      const span = document.createElement('span');
      span.className = 'char-span';
      span.textContent = char === ' ' ? '\u00A0' : char; // preserve non-breaking space
      headingEl.appendChild(span);
      
      // Animate with 200ms initial delay + 30ms stagger
      const delay = 200 + charCount * 30;
      setTimeout(() => {
        span.classList.add('revealed');
      }, delay);
      charCount++;
    }
  }

  // Hero Description: 800ms delay, 1000ms duration
  setTimeout(()=>{
    const desc = document.getElementById('hero-description');
    if(desc) desc.classList.add('revealed');
  }, 800);

  // Hero Buttons: 1200ms delay
  setTimeout(()=>{
    const btns = document.getElementById('hero-buttons-row');
    if(btns) btns.classList.add('revealed');
  }, 1200);

  // Hero Right Card: 1400ms delay
  setTimeout(()=>{
    const rc = document.getElementById('hero-right-col');
    if(rc) rc.classList.add('revealed');
  }, 1400);
}
// ============================================================
// SEAMLESS TRANSITION FROM HERO LANDING TO 3D CITY SIMULATOR
// ============================================================
window.launchSimulatorFromHero = function(){
  const hero = document.getElementById('hero-landing');
  const uiOverlay = document.getElementById('ui-overlay');
  const intelModal = document.getElementById('intelligence-modal');
  
  if (intelModal && intelModal.classList.contains('open')) {
    intelModal.classList.remove('open');
  }

  // Instantly fade out hero landing overlay
  if (hero) {
    hero.classList.add('fade-out');
    setTimeout(() => {
      hero.style.display = 'none';
    }, 700);
  }

  // Reveal 3D simulator UI dashboard
  if (uiOverlay) {
    uiOverlay.style.display = 'block';
    uiOverlay.style.pointerEvents = 'auto';
    setTimeout(() => {
      uiOverlay.style.opacity = '1';
    }, 50);
  }

  // Smooth camera glide into orbit view
  if (typeof camTransition !== 'undefined' && typeof camera !== 'undefined' && typeof controls !== 'undefined') {
    camTransition.startPos.copy(camera.position);
    camTransition.endPos.set(90, 65, 90);
    camTransition.startTarget.copy(controls.target);
    camTransition.endTarget.set(0, 5, 0);
    camTransition.duration = 1.4;
    camTransition.elapsed = 0;
    camTransition.active = true;
    camTransition.onComplete = () => {
      camera.position.set(90, 65, 90);
      controls.target.set(0, 5, 0);
    };
  }
};

window.returnToLandingPage = function(){
  const hero = document.getElementById('hero-landing');
  const uiOverlay = document.getElementById('ui-overlay');
  
  if (uiOverlay) {
    uiOverlay.style.opacity = '0';
    uiOverlay.style.pointerEvents = 'none';
  }
  
  if (hero) {
    hero.style.display = 'flex';
    setTimeout(() => {
      hero.classList.remove('fade-out');
    }, 20);
  }
  
  if (typeof camera !== 'undefined' && typeof controls !== 'undefined') {
    camera.position.set(160, 100, 160);
    controls.target.set(0, 0, 0);
  }
};

window.scrollToHero = function(){
  const modal = document.getElementById('intelligence-modal');
  if(modal && modal.classList.contains('open')){
    modal.classList.remove('open');
  }
  window.returnToLandingPage();
};

window.openIntelligenceModal = function(subView){
  const modal = document.getElementById('intelligence-modal');
  if(modal) modal.classList.add('open');
};

window.closeIntelligenceModal = function(){
  const modal = document.getElementById('intelligence-modal');
  if(modal) modal.classList.remove('open');
};

window.toggleMobileNav = function(){
  const links = document.querySelector('.hero-nav-links');
  if(links){
    if(links.style.display === 'flex'){
      links.style.display = 'none';
    } else {
      links.style.display = 'flex';
      links.style.flexDirection = 'column';
      links.style.position = 'absolute';
      links.style.top = '70px';
      links.style.left = '20px';
      links.style.right = '20px';
      links.style.padding = '20px';
      links.style.background = 'rgba(6,6,16,0.95)';
      links.style.borderRadius = '14px';
    }
  }
};

// ============================================================
// REAL-TIME ENVIRONMENTAL API LAYER (MULTI-TIERED FALLBACK ARCHITECTURE)
// Priority: OpenWeatherMap (coords) -> WeatherAPI -> Tomorrow.io -> Open-Meteo -> Cached
// Terrain: OpenTopography -> Open-Meteo Elevation -> Cached
// ============================================================
const CITY_COORDINATES = {
  Miami: { lat: 25.7617, lon: -80.1918, name: 'Miami, FL', elevation: 2.1 },
  Tokyo: { lat: 35.6762, lon: 139.6503, name: 'Tokyo, Japan', elevation: 14.5 },
  NewYork: { lat: 40.7128, lon: -74.0060, name: 'New York, USA', elevation: 10.2 },
  London: { lat: 51.5074, lon: -0.1278, name: 'London, UK', elevation: 15.0 },
  SanFrancisco: { lat: 37.7749, lon: -122.4194, name: 'San Francisco, CA', elevation: 16.0 },
  Singapore: { lat: 1.3521, lon: 103.8198, name: 'Singapore', elevation: 15.0 }
};

// Normalized Environmental Data Model
let activeEnvData = {
  city: 'Miami',
  lat: 25.7617,
  lon: -80.1918,
  tempC: 26,
  feelsLikeC: 27,
  windKmh: 14,
  windDirDeg: 120,
  humidity: 68,
  pressureHpa: 1013,
  visibilityKm: 10,
  precipitationMm: 0,
  weatherCode: 0,
  condition: 'Sunny',
  elevationM: 2.1,
  source: 'Open-Meteo',
  status: 'LIVE', // 'LIVE', 'FALLBACK', 'CACHED', 'SIMULATED'
  timestamp: new Date().toLocaleTimeString()
};

// Client-side cache to eliminate unnecessary API requests
const envDataCache = new Map();
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes cache

// Unified Environmental Service Engine
async function fetchCityWeather(cityName){
  const cityKey = cityName.replace(/\s+/g, '');
  const coords = CITY_COORDINATES[cityKey] || CITY_COORDINATES.Miami;
  const cacheKey = `${coords.lat.toFixed(3)}_${coords.lon.toFixed(3)}`;
  const now = Date.now();

  // Check valid cache
  if (envDataCache.has(cacheKey)) {
    const cachedEntry = envDataCache.get(cacheKey);
    if (now - cachedEntry.cachedAt < CACHE_TTL_MS) {
      applyEnvironmentalData(cachedEntry.data, 'CACHED');
      return;
    }
  }

  // Update UI to loading state
  const badgeText = document.getElementById('hero-weather-text');
  if(badgeText) badgeText.textContent = `FETCHING ENVIRONMENTAL DATA · ${coords.name}...`;
  const envPill = document.getElementById('env-telemetry-text');
  if(envPill) envPill.textContent = `LOADING WEATHER & WIND · ${coords.name}...`;

  let envResult = null;
  let providerSource = 'Open-Meteo';
  let providerStatus = 'LIVE';

  // 1. Attempt OpenWeatherMap if key is provided
  const owmKey = typeof process !== 'undefined' && process.env?.VITE_OPENWEATHER_API_KEY ? process.env.VITE_OPENWEATHER_API_KEY : (window.ENV?.VITE_OPENWEATHER_API_KEY || '');
  if (owmKey && owmKey.trim().length > 5) {
    try {
      const owmUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${coords.lat}&lon=${coords.lon}&units=metric&appid=${owmKey}`;
      const res = await fetch(owmUrl);
      if(res.ok) {
        const d = await res.json();
        envResult = {
          city: cityName,
          lat: coords.lat,
          lon: coords.lon,
          tempC: Math.round(d.main.temp),
          feelsLikeC: Math.round(d.main.feels_like),
          windKmh: Math.round(d.wind.speed * 3.6),
          windDirDeg: d.wind.deg || 0,
          humidity: d.main.humidity,
          pressureHpa: d.main.pressure,
          visibilityKm: (d.visibility || 10000) / 1000,
          precipitationMm: (d.rain && d.rain['1h']) || 0,
          condition: d.weather[0]?.main || 'Clear',
          elevationM: coords.elevation,
          source: 'OpenWeatherMap',
          status: 'LIVE',
          timestamp: new Date().toLocaleTimeString()
        };
        providerSource = 'OpenWeatherMap';
      }
    } catch(err) {
      console.warn('OpenWeatherMap request failed, falling back to next provider:', err);
    }
  }

  // 2. Attempt WeatherAPI if OpenWeatherMap was not available or failed
  const weatherApiKey = typeof process !== 'undefined' && process.env?.VITE_WEATHERAPI_KEY ? process.env.VITE_WEATHERAPI_KEY : (window.ENV?.VITE_WEATHERAPI_KEY || '');
  if (!envResult && weatherApiKey && weatherApiKey.trim().length > 5) {
    try {
      const wApiUrl = `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=${coords.lat},${coords.lon}`;
      const res = await fetch(wApiUrl);
      if(res.ok) {
        const d = await res.json();
        envResult = {
          city: cityName,
          lat: coords.lat,
          lon: coords.lon,
          tempC: Math.round(d.current.temp_c),
          feelsLikeC: Math.round(d.current.feelslike_c),
          windKmh: Math.round(d.current.wind_kph),
          windDirDeg: d.current.wind_degree,
          humidity: d.current.humidity,
          pressureHpa: d.current.pressure_mb,
          visibilityKm: d.current.vis_km,
          precipitationMm: d.current.precip_mm || 0,
          condition: d.current.condition?.text || 'Sunny',
          elevationM: coords.elevation,
          source: 'WeatherAPI',
          status: 'LIVE',
          timestamp: new Date().toLocaleTimeString()
        };
        providerSource = 'WeatherAPI';
      }
    } catch(err) {
      console.warn('WeatherAPI request failed, falling back to Open-Meteo:', err);
    }
  }

  // 3. Resilient Open-Meteo Live API (High-precision WMO forecast without requiring API key)
  if (!envResult) {
    try {
      const omUrl = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m&elevation=nan`;
      const res = await fetch(omUrl);
      if(res.ok) {
        const data = await res.json();
        const cur = data.current;
        let condName = 'Sunny';
        if(cur.weather_code >= 95) condName = 'Thunderstorm';
        else if(cur.weather_code >= 51) condName = 'Rain';
        else if(cur.weather_code >= 45) condName = 'Fog';
        else if(cur.weather_code >= 1) condName = 'Cloudy';
        else if(cur.wind_speed_10m > 25) condName = 'Windy';

        envResult = {
          city: cityName,
          lat: coords.lat,
          lon: coords.lon,
          tempC: Math.round(cur.temperature_2m),
          feelsLikeC: Math.round(cur.apparent_temperature || cur.temperature_2m),
          windKmh: Math.round(cur.wind_speed_10m),
          windDirDeg: cur.wind_direction_10m,
          humidity: cur.relative_humidity_2m,
          pressureHpa: Math.round(cur.surface_pressure || 1013),
          visibilityKm: 10,
          precipitationMm: cur.precipitation || 0,
          weatherCode: cur.weather_code,
          condition: condName,
          elevationM: coords.elevation,
          source: 'Open-Meteo',
          status: 'LIVE',
          timestamp: new Date().toLocaleTimeString()
        };
        providerSource = 'Open-Meteo';
      }
    } catch(err) {
      console.warn('Open-Meteo fetch failed:', err);
    }
  }

  // 4. Cached / Fallback if all network requests failed
  if (!envResult) {
    if (envDataCache.has(cacheKey)) {
      applyEnvironmentalData(envDataCache.get(cacheKey).data, 'FALLBACK');
      return;
    }
    // Safe offline fallback
    envResult = {
      city: cityName,
      lat: coords.lat,
      lon: coords.lon,
      tempC: 24,
      feelsLikeC: 25,
      windKmh: 12,
      windDirDeg: 90,
      humidity: 65,
      pressureHpa: 1014,
      visibilityKm: 10,
      precipitationMm: 0,
      weatherCode: 0,
      condition: 'Sunny',
      elevationM: coords.elevation,
      source: 'Default Base',
      status: 'FALLBACK',
      timestamp: new Date().toLocaleTimeString()
    };
    providerStatus = 'FALLBACK';
  }

  // Save to cache
  envDataCache.set(cacheKey, { data: envResult, cachedAt: now });
  applyEnvironmentalData(envResult, providerStatus);
}

function applyEnvironmentalData(envData, statusOverride) {
  activeEnvData = { ...envData };
  if(statusOverride) activeEnvData.status = statusOverride;

  // Map condition to 3D scene weather
  let simWeather = 'sunny';
  const cond = activeEnvData.condition.toLowerCase();
  if (cond.includes('storm') || cond.includes('thunder')) simWeather = 'storm';
  else if (cond.includes('rain') || cond.includes('drizzle') || activeEnvData.precipitationMm > 0) simWeather = 'rain';
  else if (cond.includes('fog') || cond.includes('mist')) simWeather = 'fog';
  else if (cond.includes('cloud') || cond.includes('overcast')) simWeather = 'cloudy';
  else if (activeEnvData.windKmh > 24) simWeather = 'wind';

  // Update Hero Badge with explicit source and live/fallback state
  const badgeText = document.getElementById('hero-weather-text');
  if(badgeText){
    badgeText.textContent = `${activeEnvData.source} [${activeEnvData.status}] · ${activeEnvData.city}: ${activeEnvData.tempC}°C ${activeEnvData.condition}`;
  }

  // Update Simulator Status Bar Pill
  const envPill = document.getElementById('env-telemetry-text');
  if(envPill){
    envPill.textContent = `${activeEnvData.city}: ${activeEnvData.tempC}°C · Wind ${activeEnvData.windKmh}km/h (${activeEnvData.windDirDeg}°) · ${activeEnvData.source} [${activeEnvData.status}]`;
  }

  // Sync 3D Scene
  state.weather = simWeather;
  updateWeather(simWeather);
  document.querySelectorAll('.weather-btn').forEach(b=>b.classList.remove('active'));
  const activeBtn = document.querySelector(`[data-weather="${simWeather}"]`);
  if(activeBtn) activeBtn.classList.add('active');
  
  const statWeather = document.getElementById('stat-weather');
  if(statWeather) statWeather.textContent = `${activeEnvData.condition} (${activeEnvData.status})`;

  // Trigger AI Prediction model update with fresh environmental feeds
  if(typeof AIPrediction !== 'undefined' && AIPrediction.update) {
    AIPrediction.update();
  }
}
window.fetchCityWeather = fetchCityWeather;
window.applyEnvironmentalData = applyEnvironmentalData;

// Initialize Hero Landing Page and Live Weather
setTimeout(()=>{
  initHeroAnimations();
  fetchCityWeather('Miami');
}, 100);

// ANIMATION LOOP
const clock=new THREE.Clock();
let aiTimer=0,analyticsTimer=0;

function animate(){
  requestAnimationFrame(animate);
  const rawDelta=clock.getDelta();
  const delta=Math.min(rawDelta, 0.1); // Cap delta to prevent huge jumps on tab switch
  const elapsed=clock.getElapsedTime();
  const timeScale = delta * 60; // Standard 60 FPS reference multiplier

  state.frameCount++;
  const now=performance.now();
  if(now-state.lastFpsTime>=1000){state.fps=state.frameCount;state.frameCount=0;state.lastFpsTime=now;document.getElementById('fps-counter').textContent=state.fps+' FPS';}

  // Camera transition animation
  updateCameraTransition(delta);

  if(state.autoTime){state.time+=delta*0.1;if(state.time>=24)state.time=0;document.getElementById('time-slider').value=state.time;updateTimeDisplay();}
  updateDayNightCycle(state.time);

  if(state.autoFlood){const target=state.weather==='storm'?12:state.weather==='rain'?6:2;state.floodLevel=THREE.MathUtils.lerp(state.floodLevel,target,delta*0.1);document.getElementById('flood-slider').value=state.floodLevel;document.getElementById('flood-level-label').textContent='Water Level: '+state.floodLevel.toFixed(1)+'m';updateFloodSimulation();}

  aiTimer+=delta;if(aiTimer>2){aiTimer=0;AIPrediction.update();}
  analyticsTimer+=delta;if(analyticsTimer>1){analyticsTimer=0;Analytics.update();}

  // Ocean waves
  const op=ocean.geometry.attributes.position;
  for(let i=0;i<op.count;i++){const x=oceanOrigPos.getX(i),y=oceanOrigPos.getY(i);op.setZ(i,Math.sin(x*0.1+elapsed*1.4)*0.5+Math.sin(y*0.14+elapsed*1.1)*0.3+Math.sin((x+y)*0.07+elapsed*0.75)*0.18);}
  op.needsUpdate=true;ocean.geometry.computeVertexNormals();

  if(floodWater.visible){
    const fp=floodWater.geometry.attributes.position;
    for(let i=0;i<fp.count;i++){const x=fp.getX(i),y=fp.getY(i);fp.setZ(i,Math.sin(x*0.04+elapsed)*0.15+Math.sin(y*0.03+elapsed*0.6)*0.12);}
    fp.needsUpdate=true;
  }

  boats.forEach(b=>{b.mesh.position.x+=Math.sin(elapsed*b.speed+b.angle)*0.018*timeScale;b.mesh.position.y=Math.sin(elapsed*0.45+b.angle)*0.28-0.5;b.mesh.rotation.z=Math.sin(elapsed*0.28+b.angle)*0.04;});

  // VEHICLES — realistic road network pathing, smooth intersection turns, lane following & collision avoidance
  if(state.trafficEnabled){
    vehicles.forEach((v, vIdx)=>{
      // Dynamic spacing check against nearby vehicles on the same or forward road
      let speedFactor = 1.0;
      for(let j = 0; j < vehicles.length; j++){
        if(vIdx === j) continue;
        const other = vehicles[j];
        const dist = v.mesh.position.distanceTo(other.mesh.position);
        if(dist < MIN_VEHICLE_DISTANCE){
          // Check if other vehicle is in front
          const toOther = new THREE.Vector3().subVectors(other.mesh.position, v.mesh.position);
          const fwd = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), v.mesh.rotation.y);
          if(toOther.dot(fwd) > 0){
            speedFactor = Math.max(0.1, (dist - 3.0) / MIN_VEHICLE_DISTANCE);
            break;
          }
        }
      }

      const speedDist = v.speed * speedFactor * delta * 25; // Frame-rate independent speed in world units

      if(!v.turning){
        // Move forward along current road segment lane
        const pts = getSegmentLaneWaypoints(v.currentSeg);
        const segLen = pts[0].distanceTo(pts[1]);
        if(segLen > 0.001){
          v.segProgress += speedDist / segLen;
        }

        if(v.segProgress < 1.0){
          // Interpolate position along current segment
          v.mesh.position.lerpVectors(pts[0], pts[1], v.segProgress);
          v.mesh.position.y = 0; // Ground level alignment (vehicle geometry has tires touching y=0.02)

          // Vehicle heading from path direction
          const dir = new THREE.Vector3().subVectors(pts[1], pts[0]).normalize();
          if(dir.lengthSq() > 0.001){
            const targetRotY = angleFromDirection(dir);
            let diff = targetRotY - v.mesh.rotation.y;
            while(diff > Math.PI) diff -= Math.PI * 2;
            while(diff < -Math.PI) diff += Math.PI * 2;
            v.mesh.rotation.y += diff * 0.25;
          }
        } else {
          // Reached end of segment at intersection node
          const endNodeId = v.currentSeg.to;
          const nextCandidates = (nodeOutgoingSegments[endNodeId] || []).filter(s => s.id !== v.currentSeg.id + '_R' && s.from === endNodeId);

          let chosenNext = null;
          if(nextCandidates.length > 0){
            chosenNext = nextCandidates[Math.floor(Math.random() * nextCandidates.length)];
          } else {
            // Dead end or boundary turnaround
            const reverseId = v.currentSeg.id.endsWith('_R') ? v.currentSeg.id.replace('_R', '') : v.currentSeg.id + '_R';
            chosenNext = roadSegments.find(s => s.id === reverseId) || roadSegments[0];
          }

          // Initiate smooth turning curve through intersection
          v.turning = true;
          v.turnCurve = buildTurnCurve(v.currentSeg, chosenNext);
          v.turnProgress = 0;
          v.nextSeg = chosenNext;
        }
      } else {
        // Navigating through intersection on quadratic bezier curve
        const curveLen = v.turnCurve.getLength();
        v.turnProgress += (speedDist * 0.85) / Math.max(curveLen, 1);

        if(v.turnProgress < 1.0){
          const pos = v.turnCurve.getPointAt(v.turnProgress);
          v.mesh.position.copy(pos);
          v.mesh.position.y = 0;

          // Smoothly rotate tangent to curve
          const tangent = v.turnCurve.getTangentAt(Math.min(v.turnProgress + 0.05, 1.0));
          if(tangent.lengthSq() > 0.001){
            const targetRotY = angleFromDirection(tangent);
            // Angle difference wrapping
            let diff = targetRotY - v.mesh.rotation.y;
            while(diff > Math.PI) diff -= Math.PI * 2;
            while(diff < -Math.PI) diff += Math.PI * 2;
            v.mesh.rotation.y += diff * 0.25;
          }
        } else {
          // Completed turn, continue along next road segment
          v.turning = false;
          v.currentSeg = v.nextSeg;
          v.segProgress = 0.02;
          const pts = getSegmentLaneWaypoints(v.currentSeg);
          v.mesh.position.copy(pts[0]);
          v.mesh.position.y = 0;
          const dir = new THREE.Vector3().subVectors(pts[1], pts[0]).normalize();
          v.mesh.rotation.y = angleFromDirection(dir);
        }
      }

      // Realistic wheel rotation tied to forward movement
      if(v.wheels){
        v.wheels.forEach(w=>{
          w.rotation.x += v.speed * timeScale * 0.45;
        });
      }
    });
  }

  // PEDESTRIANS — clamped to sidewalk zones with delta time
  if(state.pedestriansEnabled){
    pedestrians.forEach(ped=>{
      const z=ped.zone;
      const pedMove = ped.dir * ped.speed * timeScale;
      if(z.axis==='x'){
        ped.mesh.position.x += pedMove;
        if(ped.mesh.position.x>z.xMax){ped.mesh.position.x=z.xMax;ped.dir=-1;}
        if(ped.mesh.position.x<z.xMin){ped.mesh.position.x=z.xMin;ped.dir=1;}
      } else {
        ped.mesh.position.z += pedMove;
        if(ped.mesh.position.z>z.zMax){ped.mesh.position.z=z.zMax;ped.dir=-1;}
        if(ped.mesh.position.z<z.zMin){ped.mesh.position.z=z.zMin;ped.dir=1;}
      }
      ped.mesh.position.y=Math.abs(Math.sin(elapsed*5+ped.walkOffset))*0.08;
    });
  }

  clouds.forEach(c=>{c.mesh.position.x+=c.speed*timeScale;if(c.mesh.position.x>250)c.mesh.position.x=-250;});
  trees.forEach(t=>{const ws=(state.weather==='wind'||state.weather==='storm')?0.12:0.025;t.mesh.rotation.z=Math.sin(elapsed*1.4+t.mesh.position.x*0.1)*ws;t.mesh.rotation.x=Math.sin(elapsed*1.1+t.mesh.position.z*0.1)*ws*0.5;});
  lhG.rotation.y+=0.008*timeScale;lhBeam.rotation.y+=0.008*timeScale;

  birds.forEach(b=>{b.angle+=b.speed*timeScale;b.mesh.position.x=b.center.x+Math.cos(b.angle)*b.radius;b.mesh.position.z=b.center.z+Math.sin(b.angle)*b.radius;b.mesh.position.y=b.height+Math.sin(elapsed*2+b.angle)*1.8;b.mesh.rotation.y=-b.angle+Math.PI/2;if(b.mesh.children[1])b.mesh.children[1].rotation.x=Math.sin(elapsed*10)*0.4;});

  fountainParticles.forEach(p=>{
    p.mesh.position.x += p.vel.x * timeScale;
    p.mesh.position.y += p.vel.y * timeScale;
    p.mesh.position.z += p.vel.z * timeScale;
    p.vel.y -= 0.004 * timeScale;
    p.life -= 1 * timeScale;
    if(p.life<=0||p.mesh.position.y<p.base.y+0.3){
      p.mesh.position.set(p.base.x+(Math.random()-0.5)*0.5,p.base.y+2.5,p.base.z+(Math.random()-0.5)*0.5);
      p.vel.set((Math.random()-0.5)*0.18,0.12+Math.random()*0.16,(Math.random()-0.5)*0.18);
      p.life=50+Math.random()*40;
    }
  });

  // FERRIS WHEEL ANIMATION: continuous delta-time rotation around central axle y=15
  if(typeof wheelMeshGroup !== 'undefined' && wheelMeshGroup){
    wheelMeshGroup.rotation.z += 0.08 * delta;
    
    // Position cabins along circumference and keep them perfectly upright
    const wheelRot = wheelMeshGroup.rotation.z;
    if(typeof ferrisCabins !== 'undefined' && ferrisCabins.length){
      ferrisCabins.forEach(cabObj => {
        const ang = wheelRot + (cabObj.index / 12) * Math.PI * 2;
        cabObj.group.position.set(
          Math.cos(ang) * 10,
          15 + Math.sin(ang) * 10,
          0
        );
        // Keep cabin upright (zero z-tilt)
        cabObj.group.rotation.z = 0;
      });
    }
  }

  trafficLights.forEach(tl=>{tl.timer+=1*timeScale;if(tl.timer>250){tl.timer=0;tl.state=(tl.state+1)%3;}tl.redMat.emissiveIntensity=tl.state===0?1.2:0.08;tl.yellowMat.emissiveIntensity=tl.state===1?1.2:0.08;tl.greenMat.emissiveIntensity=tl.state===2?1.2:0.08;});

  if(state.weather==='rain'||state.weather==='storm'){
    const rp=rain.geometry.attributes.position;
    // Apply wind drift to rain based on live environmental wind speed and angle
    const windDrift = (activeEnvData.windKmh / 50) * Math.sin(activeEnvData.windDirDeg * Math.PI / 180);
    for(let i=0;i<6000*3;i+=3){
      rp.array[i+1]-=(state.weather==='storm'?3:2)*timeScale;
      rp.array[i] += windDrift * timeScale;
      if(rp.array[i+1]<0){
        rp.array[i+1]=120+Math.random()*80;
        rp.array[i]=(Math.random()-0.5)*300;
      }
    }
    rp.needsUpdate=true;
  }
  if(state.weather==='storm'&&Math.random()<0.008){sunLight.intensity=4;setTimeout(()=>{sunLight.intensity=0;},80);}

  if(state.earthquakeIntensity>0){
    const sh=state.earthquakeIntensity*0.018;
    camera.position.x+=(Math.random()-0.5)*sh;camera.position.y+=(Math.random()-0.5)*sh*0.5;camera.position.z+=(Math.random()-0.5)*sh;
    buildings.forEach((b,i)=>{const sw=state.earthquakeIntensity*0.004;b.rotation.z=Math.sin(elapsed*3+i)*sw;b.rotation.x=Math.cos(elapsed*2.5+i)*sw*0.5;});
  } else {buildings.forEach(b=>{b.rotation.z=THREE.MathUtils.lerp(b.rotation.z,0,0.1);b.rotation.x=THREE.MathUtils.lerp(b.rotation.x,0,0.1);});}

  if(state.fireSimulation){
    const windSmokeDrift = (activeEnvData.windKmh / 40) * 0.02 * timeScale;
    fireParticles.forEach(p=>{
      p.mesh.position.y+=p.speed*timeScale;
      p.mesh.position.x+=windSmokeDrift*0.5;
      p.mesh.scale.setScalar(1+Math.sin(elapsed*5)*0.28);
      p.mat.opacity=0.55+Math.sin(elapsed*8)*0.25;
      if(p.mesh.position.y>p.baseY+2.8){
        p.mesh.position.y=p.baseY;
        p.mesh.position.x=p.baseX || p.mesh.position.x;
      }
    });
    smokeParticles.forEach(p=>{
      p.mesh.position.y+=p.speed*timeScale;
      p.mesh.position.x+=windSmokeDrift + Math.sin(elapsed+p.mesh.position.y)*0.008*timeScale;
      p.mat.opacity=Math.max(0,0.38-(p.mesh.position.y-p.baseY)*0.05);
      if(p.mesh.position.y>p.baseY+8){
        p.mesh.position.y=p.baseY;
        p.mat.opacity=0.38;
      }
    });
  }
  if(state.showEvacuation){evacuationRoutes.forEach(m=>{m.emissiveIntensity=0.5+Math.sin(elapsed*3)*0.5;});}

  globe.rotation.y+=0.002*timeScale;land.rotation.y+=0.002*timeScale;globeRenderer.render(globeScene,globeCamera);
  controls.update();composer.render();
}

window.addEventListener('resize',()=>{
  camera.aspect=window.innerWidth/window.innerHeight;camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth,window.innerHeight);composer.setSize(window.innerWidth,window.innerHeight);
  bloomPass.resolution.set(window.innerWidth,window.innerHeight);
});

document.getElementById('stat-objects').textContent=scene.children.length+buildings.length+vehicles.length+pedestrians.length+trees.length;

// ============================================================
// PART 1 & 5 — UNIVERSAL LIQUID GLASS BUTTON CONTROLLER
// Interpolated smooth mouse-following pointer light physics
// ============================================================
(function initLiquidGlassButtons() {
  const trackedButtons = new Set();
  const buttonStates = new Map();

  function initButton(btn) {
    if (buttonStates.has(btn)) return;
    const state = {
      currentX: 50,
      currentY: 50,
      targetX: 50,
      targetY: 50,
      currentOpacity: 0,
      targetOpacity: 0,
      isHovered: false
    };
    buttonStates.set(btn, state);

    btn.addEventListener('mouseenter', (e) => {
      state.isHovered = true;
      state.targetOpacity = 1;
      const rect = btn.getBoundingClientRect();
      state.targetX = ((e.clientX - rect.left) / rect.width) * 100;
      state.targetY = ((e.clientY - rect.top) / rect.height) * 100;
      trackedButtons.add(btn);
    });

    btn.addEventListener('mousemove', (e) => {
      const rect = btn.getBoundingClientRect();
      state.targetX = ((e.clientX - rect.left) / rect.width) * 100;
      state.targetY = ((e.clientY - rect.top) / rect.height) * 100;
    });

    btn.addEventListener('mouseleave', () => {
      state.isHovered = false;
      state.targetOpacity = 0;
    });

    // Touch device support (tap feedback without mouse physics)
    btn.addEventListener('touchstart', () => {
      btn.style.setProperty('--glow-opacity', '0.7');
      btn.style.setProperty('--mouse-x', '50%');
      btn.style.setProperty('--mouse-y', '50%');
    }, { passive: true });

    btn.addEventListener('touchend', () => {
      setTimeout(() => {
        btn.style.setProperty('--glow-opacity', '0');
      }, 300);
    }, { passive: true });
  }

  // Scan and attach to all existing and dynamic buttons across the entire website
  function registerAllButtons() {
    const selector = 'button, .glass-btn, .action-btn, .weather-btn, .camera-btn, .photo-btn, .btn-hero-launch, .btn-hero-explore, .btn-launch-nav, .hm-btn, .radius-btn, .home-return-btn';
    document.querySelectorAll(selector).forEach(initButton);
  }

  registerAllButtons();
  // Observer for dynamically injected buttons or modals
  const observer = new MutationObserver(() => registerAllButtons());
  observer.observe(document.body, { childList: true, subtree: true });

  // Single shared requestAnimationFrame loop for ultra-smooth 60fps damped interpolation
  function updateGlassLightPhysics() {
    if (trackedButtons.size > 0) {
      trackedButtons.forEach(btn => {
        const s = buttonStates.get(btn);
        if (!s) { trackedButtons.delete(btn); return; }

        // Lerp coordinates
        s.currentX += (s.targetX - s.currentX) * 0.18;
        s.currentY += (s.targetY - s.currentY) * 0.18;
        s.currentOpacity += (s.targetOpacity - s.currentOpacity) * 0.15;

        btn.style.setProperty('--mouse-x', `${s.currentX.toFixed(2)}%`);
        btn.style.setProperty('--mouse-y', `${s.currentY.toFixed(2)}%`);
        btn.style.setProperty('--glow-opacity', s.currentOpacity.toFixed(3));

        if (!s.isHovered && s.currentOpacity < 0.005) {
          s.currentOpacity = 0;
          btn.style.setProperty('--glow-opacity', '0');
          trackedButtons.delete(btn);
        }
      });
    }
    requestAnimationFrame(updateGlassLightPhysics);
  }
  requestAnimationFrame(updateGlassLightPhysics);
})();

// ============================================================
// PART 8 - 24 — INTERACTIVE SATELLITE FLOOD RISK MAP ENGINE
// Real Leaflet instance, Esri Satellite, water body detection,
// red risk screening buffers, elevation & precipitation telemetry
// ============================================================
let satelliteMap = null;
let currentTileLayer = null;
let floodRiskLayerGroup = null;
let locationMarker = null;
let currentRiskRadius = 500; // in meters

const mapTileProviders = {
  satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
  osm: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
};

const tileAttributions = {
  satellite: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
  dark: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
  osm: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
};

// Known geographic water body centroids & geometries for high-risk flood screening zones
const sampleWaterFeatures = [
  // Miami coastal water bodies & Biscayne Bay
  { name: 'Biscayne Bay Coastline', lat: 25.7617, lng: -80.1918, type: 'coastline', severity: 'HIGH', baseElevation: 1.8, waterDist: 120 },
  { name: 'Miami River Basin', lat: 25.7781, lng: -80.2089, type: 'river', severity: 'HIGH', baseElevation: 2.1, waterDist: 45 },
  { name: 'Venetian Islands Channel', lat: 25.7905, lng: -80.1700, type: 'bay', severity: 'HIGH', baseElevation: 1.2, waterDist: 30 },
  
  // Chennai flood risk zones (Adyar & Cooum rivers)
  { name: 'Adyar River Estuary', lat: 13.0067, lng: 80.2575, type: 'river', severity: 'HIGH', baseElevation: 3.5, waterDist: 60 },
  { name: 'Cooum River Basin', lat: 13.0827, lng: 80.2707, type: 'river', severity: 'HIGH', baseElevation: 4.2, waterDist: 85 },
  { name: 'Marina Beach Coastline', lat: 13.0500, lng: 80.2824, type: 'coastline', severity: 'HIGH', baseElevation: 2.0, waterDist: 110 },
  
  // Tokyo Bay
  { name: 'Tokyo Bay Waterfront', lat: 35.6528, lng: 139.7944, type: 'bay', severity: 'MODERATE', baseElevation: 3.1, waterDist: 210 },
  { name: 'Sumida River Delta', lat: 35.6667, lng: 139.7833, type: 'river', severity: 'MODERATE', baseElevation: 2.8, waterDist: 95 },
  
  // London Thames
  { name: 'River Thames Embankment', lat: 51.5074, lng: -0.1278, type: 'river', severity: 'MODERATE', baseElevation: 7.5, waterDist: 90 },
  { name: 'Isle of Dogs Flood Barrier', lat: 51.5011, lng: -0.0053, type: 'river', severity: 'HIGH', baseElevation: 4.8, waterDist: 50 }
];

window.initSatelliteMapEngine = function() {
  if (satelliteMap) return;

  const container = document.getElementById('leaflet-map-container');
  if (!container) return;

  satelliteMap = L.map('leaflet-map-container', {
    center: [25.7617, -80.1918],
    zoom: 13,
    zoomControl: false,
    attributionControl: false
  });

  // Custom Zoom Control placed nicely
  L.control.zoom({ position: 'bottomleft' }).addTo(satelliteMap);
  L.control.attribution({ position: 'bottomright', prefix: false }).addTo(satelliteMap);

  // Initial Satellite Layer
  currentTileLayer = L.tileLayer(mapTileProviders.satellite, {
    attribution: tileAttributions.satellite,
    maxZoom: 19
  }).addTo(satelliteMap);

  floodRiskLayerGroup = L.layerGroup().addTo(satelliteMap);

  // Map Click Listener for instant location screening
  satelliteMap.on('click', function(e) {
    const lat = e.latlng.lat;
    const lng = e.latlng.lng;
    inspectSatelliteCoordinates(lat, lng);
  });

  renderFloodRiskScreeningZones();
};

window.switchMapLayer = function(layerKey) {
  if (!satelliteMap || !mapTileProviders[layerKey]) return;
  if (currentTileLayer) {
    satelliteMap.removeLayer(currentTileLayer);
  }
  currentTileLayer = L.tileLayer(mapTileProviders[layerKey], {
    attribution: tileAttributions[layerKey],
    maxZoom: 19
  }).addTo(satelliteMap);
};

window.renderFloodRiskScreeningZones = function() {
  if (!floodRiskLayerGroup) return;
  floodRiskLayerGroup.clearLayers();

  // Render screening buffers around known water features
  sampleWaterFeatures.forEach(wf => {
    // Red translucent screening buffer polygon / circle
    const riskCircle = L.circle([wf.lat, wf.lng], {
      radius: currentRiskRadius,
      color: wf.severity === 'HIGH' ? 'rgba(255, 50, 50, 0.75)' : 'rgba(249, 115, 22, 0.75)',
      fillColor: wf.severity === 'HIGH' ? 'rgba(255, 0, 0, 0.22)' : 'rgba(249, 115, 22, 0.18)',
      fillOpacity: 1,
      weight: 1.8,
      className: 'flood-risk-polygon'
    });

    riskCircle.bindPopup(`
      <div style="font-family:'Inter',sans-serif;padding:6px;color:#0f172a;min-width:180px;">
        <div style="font-weight:700;font-size:0.85rem;color:#b91c1c;">${wf.name}</div>
        <div style="font-size:0.7rem;color:#64748b;margin-top:2px;">Type: ${wf.type} · Screening Buffer: ${currentRiskRadius}m</div>
        <div style="margin-top:6px;font-size:0.75rem;font-weight:600;color:#ef4444;">Status: ${wf.severity} Flood Risk Screening</div>
        <button onclick="window.flyToLocation(${wf.lat}, ${wf.lng}, '${wf.name}', ${wf.baseElevation}, ${wf.waterDist}, '${wf.severity}')" style="margin-top:8px;width:100%;padding:5px;background:#0f172a;color:#fff;border:none;border-radius:6px;font-size:0.7rem;cursor:pointer;">Inspect Telemetry</button>
      </div>
    `);

    riskCircle.addTo(floodRiskLayerGroup);
  });
};

window.setBufferRadius = function(meters) {
  currentRiskRadius = meters;
  document.querySelectorAll('.radius-btn').forEach(btn => {
    if (btn.textContent.includes(meters >= 1000 ? `${meters/1000}km` : `${meters}m`)) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  renderFloodRiskScreeningZones();
};

// Multi-factor Flood Risk Screening Algorithm
// Risk Score = f(Elevation, Water Proximity, Live Precipitation, Historical/Basin Risk Tier)
function calculateFloodScreeningScore(elevationM, waterDistanceM, rainfallMm) {
  let score = 0;
  // Elevation factor (Lower = higher risk)
  if (elevationM <= 2.0) score += 40;
  else if (elevationM <= 4.0) score += 25;
  else if (elevationM <= 8.0) score += 12;
  else score += 4;

  // Water distance factor (Closer = higher risk)
  if (waterDistanceM <= 60) score += 35;
  else if (waterDistanceM <= 150) score += 22;
  else if (waterDistanceM <= 350) score += 10;
  else score += 3;

  // Rainfall / Live precipitation factor
  if (rainfallMm >= 25.0) score += 25;
  else if (rainfallMm >= 10.0) score += 15;
  else if (rainfallMm >= 3.0) score += 8;
  else score += 2;

  if (score >= 70) return { tier: 'HIGH', label: 'Simulated High Flood Risk', color: '#ef4444' };
  if (score >= 45) return { tier: 'ELEVATED', label: 'Simulated Elevated Risk', color: '#f97316' };
  if (score >= 25) return { tier: 'MODERATE', label: 'Simulated Moderate Risk', color: '#f59e0b' };
  return { tier: 'LOW', label: 'Simulated Low Flood Risk', color: '#10b981' };
}

window.flyToLocation = async function(lat, lng, name, elev, dist, initialRisk) {
  if (!satelliteMap) return;

  satelliteMap.flyTo([lat, lng], 14, { duration: 1.5 });

  if (locationMarker) {
    satelliteMap.removeLayer(locationMarker);
  }

  // Custom Pulsing Location Pin
  const customIcon = L.divIcon({
    className: 'custom-sat-pin',
    html: `<div style="width:18px;height:18px;border-radius:50%;background:#38bdf8;box-shadow:0 0 14px #38bdf8;border:2px solid #fff;"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });

  locationMarker = L.marker([lat, lng], { icon: customIcon }).addTo(satelliteMap);

  document.getElementById('sat-location-name').textContent = name || 'Target Water Basin';
  document.getElementById('sat-coords').textContent = `${lat.toFixed(4)}° N, ${lng.toFixed(4)}° E`;
  
  let currentElev = elev !== undefined ? Number(elev) : 2.5;
  let currentDist = dist !== undefined ? Number(dist) : 100;
  let currentRain = 0;

  document.getElementById('sat-elevation').textContent = `${currentElev.toFixed(1)} m (Open-Meteo/DEM)`;
  document.getElementById('sat-water-dist').textContent = `${currentDist} m (Hydro Feature)`;
  
  // Real-time live precipitation & elevation fetch via Open-Meteo elevation API fallback
  try {
    const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=precipitation,rain,wind_speed_10m&elevation=nan`);
    if (res.ok) {
      const data = await res.json();
      if (data && data.current) {
        currentRain = Number(data.current.precipitation || data.current.rain || 0);
        if (data.elevation !== undefined && !isNaN(data.elevation)) {
          currentElev = Number(data.elevation);
          document.getElementById('sat-elevation').textContent = `${currentElev.toFixed(1)} m (Open-Meteo DEM)`;
        }
      }
    }
  } catch(e) {
    console.warn('Satellite location telemetry fetch fallback:', e);
  }

  document.getElementById('sat-rainfall').textContent = `${currentRain.toFixed(1)} mm (Live)`;

  // Compute normalized screening tier
  const riskResult = calculateFloodScreeningScore(currentElev, currentDist, currentRain);
  const riskTierEl = document.getElementById('sat-risk-tier');
  if (riskTierEl) {
    riskTierEl.textContent = riskResult.tier;
    riskTierEl.style.color = riskResult.color;
  }
};

function inspectSatelliteCoordinates(lat, lng) {
  // Approximate hydro proximity based on coastline / regional terrain
  const approxElev = Number((Math.max(0.8, Math.sin(lat * 1.5) * 6 + 3.2)).toFixed(1));
  const approxDist = Math.floor(Math.abs(Math.cos(lng * 1.2)) * 220 + 35);
  
  window.flyToLocation(
    lat, 
    lng, 
    `Sector ${lat.toFixed(3)}°, ${lng.toFixed(3)}°`,
    approxElev,
    approxDist
  );
}

window.openSatelliteView = function() {
  const modal = document.getElementById('satellite-view-modal');
  if (!modal) return;
  modal.style.display = 'block';
  setTimeout(() => {
    modal.classList.add('open');
    window.initSatelliteMapEngine();
    if (satelliteMap) {
      satelliteMap.invalidateSize();
    }
  }, 20);
};

window.closeSatelliteView = function() {
  const modal = document.getElementById('satellite-view-modal');
  if (!modal) return;
  modal.classList.remove('open');
  setTimeout(() => {
    modal.style.display = 'none';
  }, 400);
};

window.launchFromSatelliteTo3D = function() {
  window.closeSatelliteView();
  // If user was on hero, launch simulator
  const hero = document.getElementById('hero-landing');
  if (hero && !hero.classList.contains('hidden')) {
    window.launchSimulatorFromHero();
  }
};

animate();
