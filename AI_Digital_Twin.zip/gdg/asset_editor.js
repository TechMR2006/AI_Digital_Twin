// ============================================================================
// 3D ASSET EDITOR & DRAG-AND-DROP PLACEMENT SYSTEM
// Modular extension for Coastal City Digital Twin
// Preserves existing simulation, rendering loop, and scene hierarchy.
// ============================================================================

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export class AssetEditor {
  /**
   * @param {Object} options
   * @param {THREE.Scene} options.scene
   * @param {THREE.Camera} options.camera
   * @param {THREE.WebGLRenderer} options.renderer
   * @param {Object} options.controls OrbitControls instance
   * @param {THREE.Mesh} options.ground Ground mesh for raycasting
   * @param {Array<THREE.Object3D>} [options.groundSurfaces] List of meshes valid for placement (ground, beach, park, etc.)
   * @param {Function} [options.onObjectPlaced] Callback when an object is placed
   * @param {Function} [options.onObjectDeleted] Callback when an object is deleted
   */
  constructor(options) {
    this.scene = options.scene;
    this.camera = options.camera;
    this.renderer = options.renderer;
    this.controls = options.controls;
    this.ground = options.ground;
    this.groundSurfaces = options.groundSurfaces || [options.ground];
    this.onObjectPlaced = options.onObjectPlaced || null;
    this.onObjectDeleted = options.onObjectDeleted || null;

    // Raycasting & pointers
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.isPointerDown = false;
    this.pointerDownPos = { x: 0, y: 0 };

    // Editor state
    this.active = false;
    this.placementMode = false;
    this.activeAssetDef = null;
    this.previewMesh = null;
    this.previewValid = false;

    // Placed objects tracking (SEPARATE from core scene objects)
    this.placedObjects = [];
    this.selectedObject = null;
    this.selectionBox = null;

    // Transform interaction mode: 'none' | 'moving' | 'rotating'
    this.transformMode = 'none';
    this.transformStartPointer = { x: 0, y: 0 };
    this.transformInitialPos = new THREE.Vector3();
    this.transformInitialRotY = 0;

    // GLTF loader
    this.gltfLoader = new GLTFLoader();

    // Asset Catalogue Definitions
    this.assetCatalogue = [
      {
        id: 'bldg-small',
        name: 'Small Building',
        category: 'Buildings',
        icon: '🏢',
        dimensions: { w: 8, h: 14, d: 8 },
        generator: () => this.createBuildingAsset(8, 8, 14, 0x4a5568, 'Residential / Commercial')
      },
      {
        id: 'bldg-med',
        name: 'Medium Tower',
        category: 'Buildings',
        icon: '🏙️',
        dimensions: { w: 10, h: 28, d: 10 },
        generator: () => this.createBuildingAsset(10, 10, 28, 0x2b6cb0, 'Office / Mixed Use')
      },
      {
        id: 'bldg-tall',
        name: 'Skyscraper',
        category: 'Buildings',
        icon: '🌆',
        dimensions: { w: 12, h: 48, d: 12 },
        generator: () => this.createBuildingAsset(12, 12, 48, 0x319795, 'Commercial Highrise')
      },
      {
        id: 'tree-oak',
        name: 'Park Oak Tree',
        category: 'Trees',
        icon: '🌳',
        dimensions: { w: 4, h: 6, d: 4 },
        generator: () => this.createTreeAsset('oak')
      },
      {
        id: 'tree-palm',
        name: 'Coastal Palm',
        category: 'Trees',
        icon: '🌴',
        dimensions: { w: 3, h: 7, d: 3 },
        generator: () => this.createTreeAsset('palm')
      },
      {
        id: 'veh-sedan',
        name: 'Parked Sedan',
        category: 'Vehicles',
        icon: '🚗',
        dimensions: { w: 2, h: 1.5, d: 4.2 },
        generator: () => this.createStaticVehicleAsset('sedan')
      },
      {
        id: 'veh-van',
        name: 'Delivery Van',
        category: 'Vehicles',
        icon: '🚐',
        dimensions: { w: 2.2, h: 2.2, d: 5 },
        generator: () => this.createStaticVehicleAsset('van')
      },
      {
        id: 'furn-bench',
        name: 'Street Bench',
        category: 'Street Furniture',
        icon: '🪑',
        dimensions: { w: 2.4, h: 1, d: 0.8 },
        generator: () => this.createBenchAsset()
      },
      {
        id: 'furn-light',
        name: 'Modern Lamp',
        category: 'Street Furniture',
        icon: '💡',
        dimensions: { w: 0.8, h: 5.5, d: 1.2 },
        generator: () => this.createStreetLampAsset()
      }
    ];

    // Build UI and bind listeners
    this.initUI();
    this.bindEvents();
    this.initSelectionHelper();
  }

  // ==========================================================================
  // PROCEDURAL ASSET GENERATORS (Reusable, lightweight, visually distinct)
  // ==========================================================================

  createBuildingAsset(w, d, h, baseColor, usageType) {
    const group = new THREE.Group();
    group.name = 'UserPlacedAsset_Building';

    // Main tower block
    const mat = new THREE.MeshStandardMaterial({
      color: baseColor,
      roughness: 0.35,
      metalness: 0.3
    });
    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    body.position.y = h / 2;
    body.castShadow = true;
    body.receiveShadow = true;
    group.add(body);

    // Decorative roof trim / structure
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x1a202c, roughness: 0.8 });
    const roof = new THREE.Mesh(new THREE.BoxGeometry(w * 0.85, 1.2, d * 0.85), roofMat);
    roof.position.y = h + 0.6;
    roof.castShadow = true;
    group.add(roof);

    // Windows pattern (instanced / grid planes)
    const winMat = new THREE.MeshStandardMaterial({
      color: 0x90cdf4,
      emissive: 0x2b6cb0,
      emissiveIntensity: 0.35,
      roughness: 0.1,
      metalness: 0.9
    });
    const rows = Math.max(2, Math.floor(h / 3.5));
    const cols = Math.max(2, Math.floor(w / 3));
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const winFront = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.6), winMat);
        winFront.position.set(-w / 2 + 1.5 + c * (w / cols), 2.5 + r * 3.5, d / 2 + 0.02);
        group.add(winFront);

        const winBack = winFront.clone();
        winBack.position.z = -d / 2 - 0.02;
        winBack.rotation.y = Math.PI;
        group.add(winBack);
      }
    }

    if (h > 30) {
      const spire = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.25, 6, 8),
        new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9 })
      );
      spire.position.y = h + 4.2;
      group.add(spire);

      const beacon = new THREE.Mesh(
        new THREE.SphereGeometry(0.2, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xe53e3e, emissive: 0xe53e3e, emissiveIntensity: 2.0 })
      );
      beacon.position.y = h + 7.2;
      group.add(beacon);
    }

    // Attach modular future energy simulation metadata
    group.userData = {
      isUserPlaced: true,
      assetType: 'building',
      height: h,
      width: w,
      depth: d,
      floors: Math.round(h / 3.2),
      usageCategory: usageType,
      constructionEra: 'Modern Post-2020',
      energyProfile: {
        simulationReady: true,
        estimatedFloorAreaM2: Math.round(w * d * Math.round(h / 3.2)),
        hvacZoneCount: Math.round(h / 3.2)
      }
    };

    return group;
  }

  createTreeAsset(variant) {
    const group = new THREE.Group();
    group.name = 'UserPlacedAsset_Tree';

    if (variant === 'palm') {
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x654321, roughness: 0.9 });
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.4, 6, 8), trunkMat);
      trunk.position.y = 3;
      trunk.castShadow = true;
      group.add(trunk);

      const leafMat = new THREE.MeshStandardMaterial({ color: 0x38a169, roughness: 0.6 });
      const leaves = new THREE.Mesh(new THREE.SphereGeometry(2.2, 8, 6), leafMat);
      leaves.scale.set(1.4, 0.4, 1.4);
      leaves.position.y = 6.2;
      leaves.castShadow = true;
      group.add(leaves);
    } else {
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3728, roughness: 0.9 });
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.5, 3.2, 8), trunkMat);
      trunk.position.y = 1.6;
      trunk.castShadow = true;
      group.add(trunk);

      const foliageMat = new THREE.MeshStandardMaterial({ color: 0x48bb78, roughness: 0.7 });
      const f1 = new THREE.Mesh(new THREE.SphereGeometry(2.5, 8, 6), foliageMat);
      f1.position.y = 4.2;
      f1.castShadow = true;
      group.add(f1);

      const f2 = new THREE.Mesh(new THREE.SphereGeometry(1.8, 8, 6), foliageMat);
      f2.position.y = 5.8;
      f2.castShadow = true;
      group.add(f2);
    }

    group.userData = {
      isUserPlaced: true,
      assetType: 'tree',
      variant: variant
    };

    return group;
  }

  createStaticVehicleAsset(type) {
    const group = new THREE.Group();
    group.name = 'UserPlacedAsset_Vehicle';

    const isVan = type === 'van';
    const bW = isVan ? 2.2 : 1.9;
    const bH = isVan ? 2.1 : 1.25;
    const bL = isVan ? 5.0 : 4.2;
    const col = isVan ? 0xdd6b20 : 0x3182ce;

    const tireRadius = 0.35;
    const roadY = 0.02;
    const bodyCenterY = roadY + tireRadius + bH / 2;

    const body = new THREE.Mesh(
      new THREE.BoxGeometry(bW, bH, bL),
      new THREE.MeshStandardMaterial({ color: col, roughness: 0.35, metalness: 0.4 })
    );
    body.position.y = bodyCenterY;
    body.castShadow = true;
    group.add(body);

    if (!isVan) {
      const cabH = 0.65;
      const cab = new THREE.Mesh(
        new THREE.BoxGeometry(bW - 0.25, cabH, bL * 0.48),
        new THREE.MeshStandardMaterial({ color: 0x1a202c, roughness: 0.1, transparent: true, opacity: 0.85 })
      );
      cab.position.set(0, bodyCenterY + bH / 2 + cabH / 2, -bL * 0.05);
      group.add(cab);
    }

    // Wheels
    const wMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
    const wGeo = new THREE.CylinderGeometry(tireRadius, tireRadius, 0.22, 12);
    const wZ = bL * 0.32;
    const wX = bW / 2 + 0.02;
    [[-wX, roadY + tireRadius, -wZ], [wX, roadY + tireRadius, -wZ], [-wX, roadY + tireRadius, wZ], [wX, roadY + tireRadius, wZ]].forEach(([wx, wy, wz]) => {
      const w = new THREE.Mesh(wGeo, wMat);
      w.rotation.z = Math.PI / 2;
      w.position.set(wx, wy, wz);
      group.add(w);
    });

    group.userData = {
      isUserPlaced: true,
      assetType: 'vehicle_static',
      variant: type
    };

    return group;
  }

  createBenchAsset() {
    const group = new THREE.Group();
    group.name = 'UserPlacedAsset_Bench';

    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.8 });
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x2d3748, metalness: 0.7 });

    const seat = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.12, 0.75), woodMat);
    seat.position.y = 0.55;
    seat.castShadow = true;
    group.add(seat);

    const back = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.55, 0.1), woodMat);
    back.position.set(0, 0.88, -0.32);
    back.castShadow = true;
    group.add(back);

    [-0.9, 0.9].forEach(lx => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.55, 0.7), ironMat);
      leg.position.set(lx, 0.28, 0);
      leg.castShadow = true;
      group.add(leg);
    });

    group.userData = { isUserPlaced: true, assetType: 'furniture', variant: 'bench' };
    return group;
  }

  createStreetLampAsset() {
    const group = new THREE.Group();
    group.name = 'UserPlacedAsset_Lamp';

    const poleMat = new THREE.MeshStandardMaterial({ color: 0x4a5568, metalness: 0.8, roughness: 0.3 });
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.15, 5.2, 8), poleMat);
    pole.position.y = 2.6;
    pole.castShadow = true;
    group.add(pole);

    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 1.2), poleMat);
    arm.position.set(0, 5.1, 0.5);
    group.add(arm);

    const lampMat = new THREE.MeshStandardMaterial({
      color: 0xfff3c4,
      emissive: 0xfff3c4,
      emissiveIntensity: 1.5
    });
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 0.45), lampMat);
    lamp.position.set(0, 4.95, 1.0);
    group.add(lamp);

    group.userData = { isUserPlaced: true, assetType: 'furniture', variant: 'street_lamp' };
    return group;
  }

  // ==========================================================================
  // SELECTION BOX HELPER (Visual feedback for selected user objects)
  // ==========================================================================

  initSelectionHelper() {
    this.selectionBox = new THREE.BoxHelper(new THREE.Mesh(new THREE.BufferGeometry()), 0x38bdf8);
    this.selectionBox.visible = false;
    this.selectionBox.material.depthTest = false;
    this.selectionBox.material.transparent = true;
    this.selectionBox.material.opacity = 0.85;
    this.selectionBox.renderOrder = 999;
    this.scene.add(this.selectionBox);
  }

  updateSelectionHelper() {
    if (this.selectedObject && this.selectedObject.parent) {
      this.selectionBox.setFromObject(this.selectedObject);
      this.selectionBox.visible = true;
    } else {
      this.selectionBox.visible = false;
    }
  }

  // ==========================================================================
  // UI CREATION & INJECTION (Compact Liquid Glass Asset Placement Panel)
  // ==========================================================================

  initUI() {
    // 1. Add toggle button to top bar (or floating trigger)
    const topBar = document.querySelector('.top-bar');
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'asset-editor-toggle-btn';
    toggleBtn.className = 'action-btn glass-btn';
    toggleBtn.style.padding = '5px 12px';
    toggleBtn.style.fontSize = '0.72rem';
    toggleBtn.style.fontWeight = '600';
    toggleBtn.style.display = 'flex';
    toggleBtn.style.alignItems = 'center';
    toggleBtn.style.gap = '6px';
    toggleBtn.style.letterSpacing = '0.04em';
    toggleBtn.style.borderColor = 'rgba(56, 189, 248, 0.4)';
    toggleBtn.style.background = 'rgba(56, 189, 248, 0.12)';
    toggleBtn.style.color = '#7dd3fc';
    toggleBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
        <line x1="12" y1="22.08" x2="12" y2="12"></line>
      </svg>
      <span>3D Assets</span>
    `;

    if (topBar) {
      topBar.insertBefore(toggleBtn, topBar.querySelector('.time-display') || null);
    }

    // 2. Main Floating Asset Placement Panel (Collapsible / Compact)
    const panel = document.createElement('div');
    panel.id = 'asset-editor-panel';
    panel.className = 'liquid-glass';
    panel.style.cssText = `
      position: fixed;
      right: 20px;
      top: 65px;
      width: 280px;
      max-height: calc(100vh - 120px);
      border-radius: 14px;
      padding: 14px;
      z-index: 1000;
      display: none;
      flex-direction: column;
      gap: 12px;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.55), inset 0 1px 1px rgba(255, 255, 255, 0.15);
      border: 1px solid rgba(255, 255, 255, 0.14);
      overflow-y: auto;
      overflow-x: hidden;
      font-family: 'Inter', sans-serif;
      transition: opacity 0.25s ease, transform 0.25s ease;
    `;

    panel.innerHTML = `
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:8px;">
        <div style="display:flex;align-items:center;gap:7px;">
          <span style="font-size:0.95rem;font-weight:700;color:#fff;letter-spacing:0.04em;">Asset Placement</span>
          <span style="font-size:0.55rem;background:rgba(56,189,248,0.2);color:#38bdf8;padding:2px 6px;border-radius:4px;font-weight:600;">3D</span>
        </div>
        <button id="asset-panel-close-btn" class="glass-btn" style="padding:3px 7px;font-size:0.75rem;border-radius:6px;color:#94a3b8;cursor:pointer;">✕</button>
      </div>

      <!-- Mode / Status Banner -->
      <div id="asset-mode-banner" style="display:none;background:rgba(56,189,248,0.12);border:1px solid rgba(56,189,248,0.3);border-radius:8px;padding:8px 10px;font-size:0.68rem;color:#bae6fd;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <span id="asset-mode-text" style="font-weight:600;">Hover over terrain to place</span>
          <button id="asset-cancel-placement-btn" class="glass-btn" style="padding:2px 6px;font-size:0.6rem;border-radius:4px;color:#f87171;">Cancel (ESC)</button>
        </div>
      </div>

      <!-- Selected Object Controls -->
      <div id="asset-selected-box" style="display:none;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px;">
        <div style="font-size:0.65rem;color:#94a3b8;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;display:flex;justify-content:space-between;">
          <span>Selected Object</span>
          <span id="selected-asset-type-pill" style="color:#38bdf8;font-weight:600;">Building</span>
        </div>
        <div id="selected-asset-name" style="font-size:0.85rem;font-weight:600;color:#fff;margin-bottom:8px;">Custom Asset</div>
        
        <!-- Action Buttons -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;">
          <button id="btn-move-selected" class="action-btn glass-btn" style="padding:6px;font-size:0.68rem;justify-content:center;">
            <span>⇄ Move</span>
          </button>
          <button id="btn-rotate-selected" class="action-btn glass-btn" style="padding:6px;font-size:0.68rem;justify-content:center;">
            <span>↻ Rotate 45°</span>
          </button>
        </div>
        <div style="display:flex;gap:6px;">
          <button id="btn-delete-selected" class="action-btn glass-btn danger" style="flex:1;padding:6px;font-size:0.68rem;justify-content:center;color:#f87171;border-color:rgba(248,113,113,0.3);">
            <span>🗑️ Delete</span>
          </button>
          <button id="btn-deselect" class="action-btn glass-btn" style="padding:6px 12px;font-size:0.68rem;justify-content:center;">
            <span>Deselect</span>
          </button>
        </div>

        <!-- Future Energy / Building Metadata Card -->
        <div id="asset-energy-meta" style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.06);font-size:0.6rem;color:#94a3b8;display:none;">
          <div style="font-weight:600;color:#cbd5e1;margin-bottom:4px;">Building Metadata (3D BAG / CitySim ready)</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;">
            <div>Floors: <span id="meta-floors" style="color:#fff;">-</span></div>
            <div>Height: <span id="meta-height" style="color:#fff;">-</span>m</div>
            <div>Footprint: <span id="meta-footprint" style="color:#fff;">-</span>m²</div>
            <div>Usage: <span id="meta-usage" style="color:#fff;">-</span></div>
          </div>
        </div>
      </div>

      <!-- Asset Library Catalogue -->
      <div style="display:flex;flex-direction:column;gap:8px;">
        <div style="font-size:0.65rem;color:#94a3b8;text-transform:uppercase;letter-spacing:0.1em;font-weight:600;">Asset Library</div>
        <div id="asset-catalogue-grid" style="display:grid;grid-template-columns:repeat(2, 1fr);gap:7px;">
          <!-- Dynamically populated -->
        </div>
      </div>

      <!-- Custom GLB/GLTF Upload Section -->
      <div style="border-top:1px solid rgba(255,255,255,0.08);padding-top:10px;">
        <div style="font-size:0.65rem;color:#94a3b8;text-transform:uppercase;letter-spacing:0.1em;font-weight:600;margin-bottom:6px;">Custom 3D Model</div>
        <div id="asset-upload-dropzone" style="border:1px dashed rgba(255,255,255,0.2);border-radius:8px;padding:10px;text-align:center;cursor:pointer;background:rgba(255,255,255,0.02);transition:all 0.2s ease;">
          <div style="font-size:1.1rem;margin-bottom:3px;">📦</div>
          <div style="font-size:0.68rem;color:#e2e8f0;font-weight:500;">Drop .GLB / .GLTF file</div>
          <div style="font-size:0.58rem;color:#64748b;margin-top:2px;">Local 3D mesh import</div>
          <input type="file" id="asset-file-input" accept=".glb,.gltf" style="display:none;" />
        </div>
        <div id="asset-upload-status" style="font-size:0.62rem;color:#38bdf8;margin-top:4px;display:none;"></div>
      </div>

      <!-- Footer Quick Tips -->
      <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:6px;font-size:0.58rem;color:#64748b;line-height:1.4;">
        💡 Click or drag asset into city · Click terrain to place · Click placed object to move/rotate/delete
      </div>
    `;

    document.body.appendChild(panel);
    this.panel = panel;
    this.toggleBtn = toggleBtn;

    // Populate asset grid
    const grid = panel.querySelector('#asset-catalogue-grid');
    this.assetCatalogue.forEach(asset => {
      const item = document.createElement('div');
      item.className = 'asset-card-item glass-btn';
      item.draggable = true;
      item.dataset.assetId = asset.id;
      item.style.cssText = `
        padding: 8px 6px;
        border-radius: 9px;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        cursor: grab;
        border: 1px solid rgba(255, 255, 255, 0.08);
        background: rgba(255, 255, 255, 0.03);
        transition: transform 0.15s ease, border-color 0.15s ease, background 0.15s ease;
      `;
      item.innerHTML = `
        <div style="font-size:1.35rem;pointer-events:none;">${asset.icon}</div>
        <div style="font-size:0.68rem;font-weight:600;color:#f1f5f9;text-align:center;pointer-events:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100px;">${asset.name}</div>
        <div style="font-size:0.55rem;color:#94a3b8;pointer-events:none;">${asset.category}</div>
      `;

      // Hover styles
      item.addEventListener('mouseenter', () => {
        item.style.borderColor = 'rgba(56, 189, 248, 0.4)';
        item.style.background = 'rgba(56, 189, 248, 0.08)';
        item.style.transform = 'translateY(-1.5px)';
      });
      item.addEventListener('mouseleave', () => {
        item.style.borderColor = 'rgba(255, 255, 255, 0.08)';
        item.style.background = 'rgba(255, 255, 255, 0.03)';
        item.style.transform = 'translateY(0)';
      });

      // Click to start placement
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        this.startPlacement(asset);
      });

      // Drag and drop start
      item.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', asset.id);
        this.startPlacement(asset);
      });

      grid.appendChild(item);
    });

    // Wire up panel button controls
    toggleBtn.addEventListener('click', () => this.togglePanel());
    panel.querySelector('#asset-panel-close-btn').addEventListener('click', () => this.closePanel());
    panel.querySelector('#asset-cancel-placement-btn').addEventListener('click', () => this.cancelPlacement());

    // Selected object actions
    panel.querySelector('#btn-move-selected').addEventListener('click', () => this.startMoveSelected());
    panel.querySelector('#btn-rotate-selected').addEventListener('click', () => this.rotateSelected(Math.PI / 4));
    panel.querySelector('#btn-delete-selected').addEventListener('click', () => this.deleteSelected());
    panel.querySelector('#btn-deselect').addEventListener('click', () => this.deselect());

    // GLTF / GLB File upload wiring
    const dropzone = panel.querySelector('#asset-upload-dropzone');
    const fileInput = panel.querySelector('#asset-file-input');
    dropzone.addEventListener('click', () => fileInput.click());

    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = '#38bdf8';
      dropzone.style.background = 'rgba(56, 189, 248, 0.1)';
    });
    dropzone.addEventListener('dragleave', () => {
      dropzone.style.borderColor = 'rgba(255,255,255,0.2)';
      dropzone.style.background = 'rgba(255,255,255,0.02)';
    });
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.style.borderColor = 'rgba(255,255,255,0.2)';
      dropzone.style.background = 'rgba(255,255,255,0.02)';
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        this.handleModelFile(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        this.handleModelFile(e.target.files[0]);
      }
    });
  }

  togglePanel() {
    if (this.panel.style.display === 'flex') {
      this.closePanel();
    } else {
      this.openPanel();
    }
  }

  openPanel() {
    this.panel.style.display = 'flex';
    this.active = true;
    this.toggleBtn.style.background = 'rgba(56, 189, 248, 0.28)';
  }

  closePanel() {
    this.cancelPlacement();
    this.deselect();
    this.panel.style.display = 'none';
    this.active = false;
    this.toggleBtn.style.background = 'rgba(56, 189, 248, 0.12)';
  }

  // ==========================================================================
  // PLACEMENT PREVIEW & RAYCASTING
  // ==========================================================================

  startPlacement(assetDef) {
    this.cancelPlacement();
    this.deselect();

    this.activeAssetDef = assetDef;
    this.placementMode = true;

    // Create preview mesh clone with semi-transparent ghost material
    const baseObj = assetDef.generator();
    baseObj.traverse(child => {
      if (child.isMesh) {
        child.castShadow = false;
        child.receiveShadow = false;
        if (Array.isArray(child.material)) {
          child.material = child.material.map(m => this.createGhostMaterial(m.color));
        } else {
          child.material = this.createGhostMaterial(child.material ? child.material.color : 0x38bdf8);
        }
      }
    });

    baseObj.visible = false;
    this.scene.add(baseObj);
    this.previewMesh = baseObj;

    // Update UI status banner
    const banner = this.panel.querySelector('#asset-mode-banner');
    const text = this.panel.querySelector('#asset-mode-text');
    banner.style.display = 'block';
    text.textContent = `Placing: ${assetDef.name} (Click terrain)`;
  }

  createGhostMaterial(baseColor) {
    return new THREE.MeshStandardMaterial({
      color: baseColor || 0x38bdf8,
      transparent: true,
      opacity: 0.65,
      roughness: 0.4,
      metalness: 0.2,
      wireframe: false
    });
  }

  cancelPlacement() {
    if (this.previewMesh) {
      this.scene.remove(this.previewMesh);
      this.disposeHierarchy(this.previewMesh);
      this.previewMesh = null;
    }
    this.placementMode = false;
    this.activeAssetDef = null;
    this.previewValid = false;

    const banner = this.panel.querySelector('#asset-mode-banner');
    if (banner) banner.style.display = 'none';
  }

  // ==========================================================================
  // OBJECT SELECTION, TRANSFORMS & DELETION
  // ==========================================================================

  selectObject(obj) {
    if (this.placementMode) return;

    // Check if clicked object is user-placed
    let root = obj;
    while (root && root.parent && root.parent !== this.scene) {
      root = root.parent;
    }

    if (!root || !root.userData || !root.userData.isUserPlaced) {
      // Core city object clicked: do not select or mutate
      this.deselect();
      return;
    }

    this.selectedObject = root;
    this.updateSelectionHelper();

    // Show selection UI card
    const selBox = this.panel.querySelector('#asset-selected-box');
    const typePill = this.panel.querySelector('#selected-asset-type-pill');
    const nameEl = this.panel.querySelector('#selected-asset-name');
    const energyCard = this.panel.querySelector('#asset-energy-meta');

    selBox.style.display = 'block';
    typePill.textContent = (root.userData.assetType || 'Asset').toUpperCase();
    nameEl.textContent = root.name.replace('UserPlacedAsset_', '') + ' #' + root.id;

    // If building, display energy & geometric metadata
    if (root.userData.assetType === 'building') {
      energyCard.style.display = 'block';
      this.panel.querySelector('#meta-floors').textContent = root.userData.floors || '-';
      this.panel.querySelector('#meta-height').textContent = root.userData.height || '-';
      this.panel.querySelector('#meta-footprint').textContent = (root.userData.width * root.userData.depth) || '-';
      this.panel.querySelector('#meta-usage').textContent = root.userData.usageCategory || 'Standard';
    } else {
      energyCard.style.display = 'none';
    }

    // Ensure asset panel is visible when user selects an object
    this.openPanel();
  }

  deselect() {
    this.selectedObject = null;
    this.transformMode = 'none';
    if (this.controls) this.controls.enabled = true;
    this.updateSelectionHelper();

    const selBox = this.panel.querySelector('#asset-selected-box');
    if (selBox) selBox.style.display = 'none';
  }

  startMoveSelected() {
    if (!this.selectedObject) return;
    this.transformMode = 'moving';
    if (this.controls) this.controls.enabled = false;

    const banner = this.panel.querySelector('#asset-mode-banner');
    const text = this.panel.querySelector('#asset-mode-text');
    banner.style.display = 'block';
    text.textContent = 'Moving: Click or drag on terrain to relocate';
  }

  rotateSelected(deltaRadians) {
    if (!this.selectedObject) return;
    this.selectedObject.rotation.y += deltaRadians;
    this.updateSelectionHelper();
  }

  deleteSelected() {
    if (!this.selectedObject) return;

    // CRITICAL SAFETY CHECK: NEVER delete core city objects
    if (!this.selectedObject.userData || !this.selectedObject.userData.isUserPlaced) {
      console.warn('Prevented accidental deletion of core scene object');
      return;
    }

    const target = this.selectedObject;
    const index = this.placedObjects.indexOf(target);
    if (index !== -1) {
      this.placedObjects.splice(index, 1);
    }

    this.scene.remove(target);
    this.disposeHierarchy(target);

    this.deselect();

    if (this.onObjectDeleted) {
      this.onObjectDeleted(target);
    }
  }

  // ==========================================================================
  // CUSTOM 3D MODEL IMPORT (.GLB / .GLTF)
  // ==========================================================================

  handleModelFile(file) {
    const statusEl = this.panel.querySelector('#asset-upload-status');
    statusEl.style.display = 'block';
    statusEl.style.color = '#38bdf8';
    statusEl.textContent = `Loading ${file.name}...`;

    const extension = file.name.split('.').pop().toLowerCase();
    if (extension !== 'glb' && extension !== 'gltf') {
      statusEl.style.color = '#f87171';
      statusEl.textContent = 'Error: Only .glb or .gltf files supported';
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const contents = e.target.result;
      this.gltfLoader.parse(
        contents,
        '',
        (gltf) => {
          const model = gltf.scene || gltf.scenes[0];
          
          // Compute bounding box and normalize scale to sensible city size (~8m)
          const box = new THREE.Box3().setFromObject(model);
          const size = new THREE.Vector3();
          box.getSize(size);
          const maxDim = Math.max(size.x, size.y, size.z);
          const targetScale = maxDim > 0 ? (10 / maxDim) : 1;
          model.scale.setScalar(targetScale);

          // Center pivot at ground base
          box.setFromObject(model);
          model.position.y = -box.min.y;

          const customWrapper = new THREE.Group();
          customWrapper.name = `UserPlacedAsset_Custom_${file.name.replace(/\.[^/.]+$/, '')}`;
          customWrapper.add(model);
          customWrapper.userData = {
            isUserPlaced: true,
            assetType: 'custom_upload',
            fileName: file.name
          };

          const customDef = {
            id: 'custom-' + Date.now(),
            name: file.name.substring(0, 15),
            category: 'Custom Upload',
            icon: '📦',
            generator: () => customWrapper.clone()
          };

          statusEl.style.color = '#4ade80';
          statusEl.textContent = `Loaded ${file.name}! Starting placement...`;

          this.startPlacement(customDef);
        },
        (error) => {
          console.error('GLTF loading error:', error);
          statusEl.style.color = '#f87171';
          statusEl.textContent = 'Failed to parse 3D model file';
        }
      );
    };

    reader.onerror = () => {
      statusEl.style.color = '#f87171';
      statusEl.textContent = 'Failed to read file';
    };

    reader.readAsArrayBuffer(file);
  }

  // ==========================================================================
  // POINTER & DRAG-AND-DROP EVENT HANDLING
  // ==========================================================================

  bindEvents() {
    const dom = this.renderer.domElement;

    dom.addEventListener('pointerdown', (e) => this.onPointerDown(e));
    dom.addEventListener('pointermove', (e) => this.onPointerMove(e));
    dom.addEventListener('pointerup', (e) => this.onPointerUp(e));

    // Handle dragover / drop directly from external or internal dragging
    dom.addEventListener('dragover', (e) => {
      e.preventDefault();
      this.updatePointerCoords(e);
      if (this.placementMode && this.previewMesh) {
        this.updatePreviewPosition();
      }
    });

    dom.addEventListener('drop', (e) => {
      e.preventDefault();
      this.updatePointerCoords(e);
      if (this.placementMode) {
        this.placeCurrentAsset();
      }
    });

    // Keyboard shortcuts: ESC to cancel/deselect, R to rotate, Delete to delete
    window.addEventListener('keydown', (e) => {
      // Don't intercept when user is typing in chat or input
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      if (e.key === 'Escape') {
        if (this.placementMode) {
          this.cancelPlacement();
        } else if (this.transformMode !== 'none') {
          this.transformMode = 'none';
          if (this.controls) this.controls.enabled = true;
          const banner = this.panel.querySelector('#asset-mode-banner');
          if (banner) banner.style.display = 'none';
        } else if (this.selectedObject) {
          this.deselect();
        }
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (this.selectedObject && !this.placementMode) {
          this.deleteSelected();
        }
      } else if (e.key === 'r' || e.key === 'R') {
        if (this.selectedObject && !this.placementMode) {
          this.rotateSelected(Math.PI / 4);
        } else if (this.previewMesh) {
          this.previewMesh.rotation.y += Math.PI / 4;
        }
      }
    });
  }

  updatePointerCoords(e) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  }

  onPointerDown(e) {
    if (e.button !== 0) return; // Only primary mouse button
    this.isPointerDown = true;
    this.pointerDownPos = { x: e.clientX, y: e.clientY };
    this.updatePointerCoords(e);
  }

  onPointerMove(e) {
    this.updatePointerCoords(e);

    // 1. Placement Mode: update ghost preview coordinates
    if (this.placementMode && this.previewMesh) {
      this.updatePreviewPosition();
      return;
    }

    // 2. Moving Selected Object
    if (this.transformMode === 'moving' && this.selectedObject) {
      this.raycastGround((point) => {
        this.selectedObject.position.set(point.x, point.y, point.z);
        this.updateSelectionHelper();
      });
      return;
    }
  }

  onPointerUp(e) {
    if (e.button !== 0) return;
    this.isPointerDown = false;

    // Check if this was a drag gesture for camera orbit
    const dragDistance = Math.hypot(e.clientX - this.pointerDownPos.x, e.clientY - this.pointerDownPos.y);
    const isClick = dragDistance < 6;

    if (!isClick) return;

    // If in Placement Mode -> Place the asset
    if (this.placementMode) {
      this.placeCurrentAsset();
      return;
    }

    // If in Move Mode -> Finish moving
    if (this.transformMode === 'moving') {
      this.transformMode = 'none';
      if (this.controls) this.controls.enabled = true;
      const banner = this.panel.querySelector('#asset-mode-banner');
      if (banner) banner.style.display = 'none';
      return;
    }

    // Otherwise: Raycast against user-placed objects for selection
    this.checkSelectionRaycast();
  }

  updatePreviewPosition() {
    this.raycastGround((point) => {
      this.previewMesh.position.set(point.x, point.y, point.z);
      this.previewMesh.visible = true;
      this.previewValid = true;
    }, () => {
      this.previewMesh.visible = false;
      this.previewValid = false;
    });
  }

  placeCurrentAsset() {
    if (!this.activeAssetDef || !this.previewValid || !this.previewMesh) return;

    // Instantiate real production asset using its generator
    const newAsset = this.activeAssetDef.generator();
    newAsset.position.copy(this.previewMesh.position);
    newAsset.rotation.copy(this.previewMesh.rotation);

    // Ensure unique ID and flags
    newAsset.userData = Object.assign({}, newAsset.userData, {
      isUserPlaced: true,
      placementTimestamp: Date.now()
    });

    this.scene.add(newAsset);
    this.placedObjects.push(newAsset);

    // Notify listeners
    if (this.onObjectPlaced) {
      this.onObjectPlaced(newAsset);
    }

    // Switch selection to new placed asset
    this.cancelPlacement();
    this.selectObject(newAsset);
  }

  checkSelectionRaycast() {
    this.raycaster.setFromCamera(this.mouse, this.camera);

    // Only raycast against user placed objects
    const intersects = this.raycaster.intersectObjects(this.placedObjects, true);

    if (intersects.length > 0) {
      this.selectObject(intersects[0].object);
    } else {
      // Clicked outside on empty ground: deselect if we didn't click the panel
      this.deselect();
    }
  }

  raycastGround(onHit, onMiss) {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.groundSurfaces, true);

    if (intersects.length > 0) {
      onHit(intersects[0].point);
    } else {
      // Fallback: Plane at y = 0
      const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
      const target = new THREE.Vector3();
      const hit = this.raycaster.ray.intersectPlane(plane, target);
      if (hit && Math.abs(target.x) < 250 && Math.abs(target.z) < 250) {
        onHit(target);
      } else if (onMiss) {
        onMiss();
      }
    }
  }

  // ==========================================================================
  // RESOURCE CLEANUP HELPER
  // ==========================================================================

  disposeHierarchy(obj) {
    obj.traverse(child => {
      if (child.isMesh) {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          if (Array.isArray(child.material)) {
            child.material.forEach(m => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      }
    });
  }
}
